﻿using System.Collections.Generic;
using UnityEngine;
using AntGame;
using AntGame.Entity;

public class TestPlayer : PlayerBase {

    public float moveSpeed = 0.001f;

    public float passForce = 100;
    //public float shootForce = 250;

	// Update is called once per frame
	void Update () {
        float h = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
        float v = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;

        Vector3 moveVector = new Vector3(h, 0, v);

        if(Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("Kick");
            //변형
            //sb.Kick(sb.transform.forward, 250);
        }

        transform.Translate(moveVector);
	}
}
