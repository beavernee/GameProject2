﻿using System.Collections.Generic;
using UnityEngine;
using Utilities;
using AntGame.Entity;

///Note
/// 물리 시뮬레이션을 어떻게 적용할지 다시 한번더 생각해본다.
namespace AntGame
{
    //추가리스트
    // Note.뺏긴놈은 아주잠깐동안 SoccerBall를 가질수없는 로직을 만들어준다.
    // PlayerBase prePlayer 
    // 버그 --> 에이전트 충돌시 y축이 조금 위로 이동 (방안. 충돌했을 때 y축을 고정시켜주는 방식으로 처리)

    /// <summary>
    /// 공의 대한 클래스
    /// OnCollisionEnter를 이용해 소유권을 변경시켜준다.
    /// </summary>
    //[RequireComponent(typeof(SphereCollider))]
    public class SoccerBall : Singleton<SoccerBall>
    {        
        // 공을 가지고 있는 선수를 가리키기 위함
        PlayerBase m_Owner = null;

        [SerializeField] Rigidbody rb;

        // Note. 현재는 사용하지 않는 변수임 삭제 예정
        [SerializeField] bool isBelongToPlayer;

        // PlayerBase preOwner;

        public PlayerBase Owner
        {
            get { return m_Owner; }
            private set { m_Owner = value; }
        }

        #region Functions

        /// <summary>
        /// 플레이어가 슛팅했을 때 호출되는 함수
        /// </summary>
        /// <param name="dir">날라갈 방향</param>
        /// <param name="force">Rigidbody에 가할 힘</param>
        public void Kicked(Vector3 dir, float force)
        {
            // 귀속을 풀고
            transform.SetParent(null);

            // 방향으로 force만큼 힘을 가한다.
            rb.AddForce(dir * force);

            BelongToPlayer();

            SetRigidbody(RigidbodyConstraints.FreezeRotation);

        }

        private void BelongToPlayer(PlayerBase _player = null)
        {
            isBelongToPlayer = (_player != null) ? true : false;

            if (Owner != null) Owner.SetOwnerOfTheBall();

            Owner = _player;

            if (Owner)
            {
                Owner.SetOwnerOfTheBall(this);

                transform.SetParent(_player.transform);

                // Rigidbody 속성변경
                SetRigidbody(RigidbodyConstraints.FreezeAll);

                // SetDirection
                transform.forward = _player.transform.forward;
            }
            else
            {
                SetRigidbody(RigidbodyConstraints.FreezeAll);
            }
        }

        private void SetRigidbody(RigidbodyConstraints _constraint)
        {   // RigidbodyConstraints.FreezeAll 
            // RigidbodyConstraints.FreezeRotation
            rb.constraints = _constraint;

            transform.position = new Vector3(this.transform.position.x, 0, this.transform.position.z);
        }

        // 뻇을수 있는지 체크
        private bool CheckCanBelongTo(Transform _transform)
        {
            Vector3 convertToLocalPoint = _transform.InverseTransformPoint(transform.position).normalized;

            if (convertToLocalPoint.z > 0)
            {
                Vector3 ToTarget = (transform.position - _transform.position).normalized;

                float dot = Vector3.Dot(ToTarget, _transform.forward);
                
                // PI/5 값보다 클 때 true를 리턴
                if(dot > Mathf.Cos(Mathf.PI * 0.2f))
                {
                    return true;
                }
            }
            return false;
        }

        #endregion


        #region MonoBehaviour 이벤트함수

        private void Reset()
        {
            rb = GetComponent<Rigidbody>();
            SetRigidbody(RigidbodyConstraints.FreezeAll);

            gameObject.layer = LayerMask.NameToLayer("Ball");
        }

        private void OnCollisionEnter(Collision collision)
        {
            SetRigidbody(RigidbodyConstraints.FreezeAll);

            if (collision.gameObject.layer == LayerMask.NameToLayer("Agent"))
            {
                if (!Owner)
                {
                    if (CheckCanBelongTo(collision.transform))
                    {
                        BelongToPlayer(collision.gameObject.GetComponent<PlayerBase>());
                    }
                }
                else
                {
                    if (Owner.gameObject != collision.gameObject)
                    {
                        if (CheckCanBelongTo(collision.transform))
                        {
                            BelongToPlayer(collision.gameObject.GetComponent<PlayerBase>());
                        }
                    }
                }
            }
            else if (collision.gameObject.layer == LayerMask.NameToLayer("Wall"))
            {
                if (!Owner)
                    BelongToPlayer();
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.gameObject.layer == LayerMask.NameToLayer("Goal"))
            {
                Debug.Log("골");
            }
        }

        #endregion

    }
}