﻿using System;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;
using Utilities.FSM;

/// Note
/// 팀이 공의 권한을 가지고 있고, ControllingPlayer기준으로 슛을 하게 설계
/// 
namespace AntGame
{
    public enum TeamColor
    {
        Red,
        Blue,
    }

    [RequireComponent(typeof(StateMachine))]
    //[RequireComponent(typeof(SupportSpotCalculator))]
    public class SoccerTeam : MonoBehaviour, IFSM_object
    {   
        #region Fields
        // 테스트용
        public GameObject DummyObject; // 최적의경로찾기위한 더미오브젝트

        [SerializeField] TeamColor m_Color;

        [SerializeField] StateMachine m_StateMachine;

        [SerializeField] List<PlayerBase> m_PlayerList;

        [SerializeField] SoccerTeam m_Oppenent;

        [SerializeField] Goal m_HomeGoal;
        [SerializeField] Goal m_OpponentGoal;

        //Note.테스트용
        public PlayerInput playerInput;

        //Note. 테스트용 삭제해도됨 프로퍼티도 수정해야한다.
        //완벽해지면 지우고 프로퍼티
        [SerializeField] bool m_authorizedTest;
        [SerializeField] SoccerBall m_Ball;

        /// <summary>
        /// 핵심 플레이어
        /// </summary>
        //PlayerBase m_RecevingPlayer;       //받는선수 --> 없어도됨 (유저가 패스를 하기 때문)
        //PlayerBase m_PlayerClosestToBall;  //공에 가장 가까운 선수
        [SerializeField] PlayerBase m_ControllingPlayer;     //제어하는 선수  플레이어 컨트롤러가 작동하는 선수가 될 것이며, 축구공에 명령을 내릴 수 있는 선수이다.
        //PlayerBase m_SupportingPlayer;     //지원하는 선수  공격수로 부터 멀리 떨어진 유용한 위치로 움직인다.

        #endregion

        #region Properties

        /// <summary>
        /// 팀이 공의 권한을 갖고 있는지 체크해주는 프로퍼티
        /// </summary>
        public bool IsAuthorizedBall
        {
            get { return m_authorizedTest; } set { m_authorizedTest = value; }
        }

        public SoccerBall sb //프로퍼티명 대충해놓음
        {
            get { return m_Ball; } set { m_Ball = value; }
        }

        public TeamColor Color { get { return m_Color; } }

        public List<PlayerBase> Members {
            get { return m_PlayerList; }
        }

        public SoccerTeam Oppenent {
            get { return m_Oppenent; }
        }

        //public PlayerBase RecevingPlayer {
        //    get { return m_RecevingPlayer; }
        //    set { m_RecevingPlayer = value; }
        //}

        public PlayerBase ControllingPlayer {
            get { return m_ControllingPlayer; }
            set {
                // 새로운 ControllingPlayer를 가리키게 될 경우에 
                // NavMeshAgent를 다시 켜준다.
                m_ControllingPlayer.getNavMeshAgent.enabled = true;

                m_ControllingPlayer = value;
                
                if(m_ControllingPlayer != null)
                    m_ControllingPlayer.getNavMeshAgent.enabled = false;
            }
        }

        //public PlayerBase PlayerClosestToBall {
        //    get { return m_PlayerClosestToBall; }
        //    set { m_PlayerClosestToBall = value; }
        //}

        //public PlayerBase SupportingPlayer {
        //    get { return m_SupportingPlayer; }
        //    set { m_SupportingPlayer = value; }
        //}

        /// <summary>
        /// IFSM_object 인터페이스 구현
        /// </summary>
        public StateMachine stateMachine {
            get { return m_StateMachine; }
            set { m_StateMachine = value; }
        }

        public GameObject getGameObject {
            get { return gameObject; }
        }

        #endregion

        public bool isPassSafeFromAllOpponents(Vector3 from, Vector3 target, PlayerBase receiver, float passingForce)
        {
            for(int i = 0; i < Oppenent.Members.Count; i++)
            {
                //if (!isPassSafeFromOpponent(from, target, receiver, Oppenent.Members[i], passingForce))
                //{
                //    return false;
                //}
            }

            return true;
        }

        // 더미 오브젝트를 이용해서 체크한다
        public bool isPassSafeFromOpponent(Vector3 from, Vector3 target, PlayerBase receiver, PlayerBase opp, float passingForce = 0)
        {
            DummyObject.transform.position = from;
            DummyObject.transform.LookAt(target);

            Vector3 convertToLocal = DummyObject.transform.InverseTransformPoint(opp.transform.position);
            Debug.Log(convertToLocal);

            if (convertToLocal.z < 0)
                return true;

            if(Vector3.Distance(from, target) < Vector3.Distance(from, opp.transform.position))
            {
                // 4/20 리시버가 있을때는 아직 코드를 안짠다.
                if(receiver)
                {

                }
            }

            // 너무많은데 미친놈들인가?

            return false;
        }

        // 아직 사용안함
        public void AddPlayerList(PlayerBase player)
        {
            m_PlayerList.Add(player);
        }

        // Player를 홈지역으로 가게 설정한다.
        public void Set_player_home_region(int _idx)
        {
            m_PlayerList[_idx].Set_home_region();
        }


        #region MonoBehaviour 이벤트함수

        private void Reset()
        {
            m_StateMachine = GetComponent<StateMachine>();
            m_StateMachine.Initialize();
        }

        private void Awake()
        {
            playerInput = GetComponent<PlayerInput>();
        }

        #endregion
    }
}
