﻿using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity
{
    /// <summary>
    /// 단순축구 예제를 보고 작성
    /// </summary>
    public class SupportSpotCalculator : MonoBehaviour
    {
        [SerializeField] SoccerTeam m_Team;

        [SerializeField] List<SupportSpot> m_Spots;

        [SerializeField] SupportSpot m_BestSupportingSpot;

        [SerializeField] bool m_isReady;
        [SerializeField] float m_fTime;
        [SerializeField] float m_fNextUpdateTime = 1.0f;

        public GameObject test;
        
        // 호출을 SoccerTeam에 위임
        public void Init()
        {
            m_Team.GetComponent<SoccerTeam>();
        }


        [ContextMenu("TestFunc")]
        private void TestFuc()
        {
            //m_BestSupportingSpot = m_Spots[0];

            this.transform.LookAt(test.transform.position);
        }

        public Vector3 DetermineBestSupportingPosition()
        {
            if(m_isReady && m_BestSupportingSpot != null)
            {
                m_isReady = false;
                return m_BestSupportingSpot.Pos;
            }
            
            // 최상의 지원 지점을 리셋한다.
            m_BestSupportingSpot = null;

            float BestScoreSoFar = 0.0f;

            for(int i = 0; i < m_Spots.Count; i++)
            {
                // 먼저 이전의 점수를 제거
                // (관찰자가 모든 지점의 위치를 볼 수 있도록 1로 설정된다.
                m_Spots[i].Score = 1.0f;
                
                // 검사 1. 공의 위치에서 이 위치까지 안전하게 패스할 수 있는지를 결정
                //if(m_Team)
            }

            return Vector3.zero;
        }


        [ContextMenu("TestFunc1")]
        public Vector3 GetBestSuppoertSpot()
        {
            if (m_isReady && m_BestSupportingSpot != null)
            {
                m_isReady = false;
                Debug.Log("최고의 포지션은 : " + m_BestSupportingSpot.Pos);
                return m_BestSupportingSpot.Pos;
            }
            else
                return DetermineBestSupportingPosition();
        }

        private void FixedUpdate()
        {
            if (!m_isReady)
            {
                if (m_fTime > m_fNextUpdateTime)
                {
                    m_fTime = 0.0f;

                    m_isReady = true;
                }

                m_fTime += Time.deltaTime;
            }
        }

        // Test
        private void Update()
        {
            //Debug.Log(transform.InverseTransformPoint(test.transform.position));
        }
    }
    
    [System.Serializable]
    public class SupportSpot
    {
        [SerializeField] Vector3 m_vPos;

        [SerializeField] float m_fScore;

        public Vector3 Pos {
            get { return m_vPos; }
        }

        public float Score {
            get { return m_fScore; }
            set { m_fScore = value; }
        }

    }

}