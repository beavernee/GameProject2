﻿using System.Collections.Generic;
using UnityEngine;
using Utilities;
using AntGame.Entity;
using Utilities.FSM;

// Network를 붙이는건 추후에 고려하자.

//Note. Region 만들기 추가해준다.

namespace AntGame
{
    public enum GameState
    {
            Ready
            , StartUp
            , KickOff
            , Playing
            , TimeOut
            , EndGame
    }

    public class GameManager : Singleton<GameManager>
    {
        public GameState m_State = GameState.Playing;
        
        //[SerializeField] SoccerBall m_Ball;
        [SerializeField] SoccerPitch m_pitch;
        [SerializeField] SoccerTeam m_Player_01_team;
        [SerializeField] SoccerTeam m_Player_02_team;


        #region Properties
        //public SoccerBall Ball
        //{
        //    set { m_Ball = value; }
        //}

        public SoccerTeam PlayerTeam01
        {
            get { return m_Player_01_team; }
        }

        public SoccerTeam PlayerTeam02
        {
            get { return m_Player_02_team; }
        }

        #endregion

        private void Update()
        {
            HandleStateMachine();
        }

        // FSM으로 구현할지, 열거자로 구현할지 
        private void HandleStateMachine()
        {
            switch (m_State)
            {
                case GameState.StartUp:
                    break;

                case GameState.Playing:
                    break;

                case GameState.EndGame:
                    break;
            }

        }
    }
}