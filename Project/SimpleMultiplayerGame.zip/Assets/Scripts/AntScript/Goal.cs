﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame
{
    /// <summary>
    /// 골대의 끝을 게임 내내 반복하는 오브젝트를 갖고 있는 
    /// 슛을 날리려는 플레이어의 공이 향하는 곳이다.
    /// </summary>
    [RequireComponent(typeof(BoxCollider))]
    public class Goal : MonoBehaviour
    {
        [SerializeField] int m_iNumGoalsScored;

        public int NumGoalsScored {
            get { return m_iNumGoalsScored; }
        }

        private void Reset()
        {
            GetComponent<BoxCollider>().isTrigger = true;
        }

        //Note. 골 관련된 부분 수정할 부분이 많다.
        private void OnTriggerEnter(Collider other)
        {
            if(other.GetComponent<SoccerBall>())
            {
                m_iNumGoalsScored++;
                //DummyFunc();
            }
        }

        private void DummyFunc()
        {

        }
    }
}