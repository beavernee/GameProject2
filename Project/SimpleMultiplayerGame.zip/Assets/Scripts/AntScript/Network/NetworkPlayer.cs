﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace AntGame.Networking
{
    public class NetworkPlayer : NetworkBehaviour
    {

        /// <summary>
        /// 지역 네트워크 플레이어를 가져온다.
        /// </summary>
        public static NetworkPlayer s_LocalPlayer
        {
            get; private set;
        }

        [Client]
        public override void OnStartLocalPlayer()
        {

        }
    }
}
