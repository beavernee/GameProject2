﻿using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;

namespace AntGame
{
    public class KeyboardInput : InputModule
    {
        public PlayerInput playerInput;

        private void Awake()
        {
            playerInput = GetComponent<PlayerInput>();
        }

        protected override void MovementInput()
        {
            //float h = Input.GetAxis("Horizontal");
            //float v = Input.GetAxis("Vertical");

            float h = 0.0f; float v = 0.0f;

            if (playerInput.Team.Color == TeamColor.Red)
            {
                if (Input.GetKey(KeyCode.W))
                {
                    v = 1;
                }

                if (Input.GetKey(KeyCode.D))
                {
                    h = 1;
                }

                if (Input.GetKey(KeyCode.S))
                {
                    v = -1;
                }

                if (Input.GetKey(KeyCode.A))
                {
                    h = -1;
                }
            }
            
            if (playerInput.Team.Color == TeamColor.Blue)
            {
                if (Input.GetKey(KeyCode.UpArrow))
                {
                    v = 1;
                }

                if (Input.GetKey(KeyCode.RightArrow))
                {
                    h = 1;
                }

                if (Input.GetKey(KeyCode.DownArrow))
                {
                    v = -1;
                }

                if (Input.GetKey(KeyCode.LeftArrow))
                {
                    h = -1;
                }
            }

            Vector3 desiredDir = new Vector3(h, 0, v).normalized;

            SetDesiredMovementDirection(desiredDir);
        }

        protected override void ShootInput()
        {
            if(playerInput.Team.Color == TeamColor.Red)
            {
                if(Input.GetKeyDown(KeyCode.LeftShift))
                {
                    Shoot();
                    Debug.Log("Red Team Shoot");
                }
            }

            if (playerInput.Team.Color == TeamColor.Blue)
            {
                if(Input.GetKeyDown(KeyCode.RightShift))
                {
                    Shoot();
                    Debug.Log("Blue Team Shoot");
                }
            }
        }
    }
}