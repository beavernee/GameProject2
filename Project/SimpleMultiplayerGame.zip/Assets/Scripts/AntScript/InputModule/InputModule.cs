﻿using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;

namespace AntGame
{
    public abstract class InputModule : MonoBehaviour
    {
        [SerializeField] protected PlayerBase control;

        // Controlling 권한이 바뀔때 호출해준다.
        // 이부분을 활용해야 한다.
        public PlayerBase Control { set { control = value; } }

        protected abstract void MovementInput();

        protected abstract void ShootInput();

        protected void SetDesiredMovementDirection(Vector3 moveDir)
        {
            control.Movement.SetDesiredMovementDirection(moveDir);
        }

        protected void Shoot()
        {
            if (control.Team.IsAuthorizedBall)
                control.Kick();
        }

        protected virtual void Update()
        {
            MovementInput();
            ShootInput();
        }
    }
}