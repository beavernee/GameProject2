﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame
{
    // 추후에 inputManager로 변경해 관리하게 한다.
    public class PlayerInput : MonoBehaviour
    {
        public InputModule Module;

        public SoccerTeam Team;

        private void Awake()
        {
            if (!Module) Module = GetComponent<InputModule>();

            if (!Team) Team = GetComponent<SoccerTeam>();
        }
    }
}