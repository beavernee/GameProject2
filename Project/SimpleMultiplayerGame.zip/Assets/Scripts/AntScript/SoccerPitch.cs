﻿using System.Collections.Generic;
using UnityEngine;
using Utilities;

namespace AntGame
{
    /// <summary>
    /// 경기장
    /// </summary>
    public class SoccerPitch : Singleton<SoccerPitch> {

        // Region을 일단 MonoBehaviour로 설정한다.
        // 빠른테스트를 위함
        public List<Region> m_Regions = new List<Region>();

        public List<Region> Regions
        {
            get { return m_Regions; }
        }

        [ContextMenu("Region Test")]
        private void Allocate()
        {
            Region[] regions = GetComponentsInChildren<Region>();

            foreach(var region in regions)
            {
                m_Regions.Add(region);
            }
        }
    }

}
