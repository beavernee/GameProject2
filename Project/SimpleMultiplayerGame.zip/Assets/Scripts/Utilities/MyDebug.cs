﻿using UnityEngine;

///<summary>
/// print, Debug.Log를 이용해서 디버깅을 하게 될 경우에 깜빡 잊고 지우지 못했을 경우에
/// String인 문자열 때문에 가비지컬렉션의 동작이 일어나는 경우를 사전에 막기 위해서
/// [System.Diagnostics.Conditional("UNITY_EDITOR")] 을 이용해서
/// UNITY_EDITOR 컴파일기호가 아닐 경우에는 컴파일러에게 무시해도 된다는 것을 알려주는 기능을 설정
///</summary>
public static class MyDebug
{
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public static void Log(object message)
    {
        Debug.Log(message);
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public static void LogError(object message)
    {
        Debug.LogError(message);
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public static void LogWarning(object message)
    {
        Debug.LogWarning(message);
    }
}
