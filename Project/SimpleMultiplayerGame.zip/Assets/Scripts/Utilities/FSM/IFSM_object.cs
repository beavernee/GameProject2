﻿using System.Collections.Generic;
using UnityEngine;

namespace Utilities.FSM
{
    /// <summary>
    /// 다중상속을 구현하기 위해서는 인터페이스를 이용한다.
    /// </summary>
    public interface IFSM_object
    {
        // 유한상태기계의 대한 프로퍼티를 갖게 한다.
        StateMachine stateMachine {
            get; set;
        }

        // IFSM_object로 접근할 수 있게 게임오브젝트
        GameObject getGameObject {
            get;
        }
    }

}