﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

//
// 추상클래스로 설계
// 고려사항 : 상태전이조건?
// UNET 통신할 때에는 템플릿을 이용할 수 없다.
// [Command] : 클라이언트에서 호출되어서 서버에서 수행
// [ClientRpc] : 서버에서 호출되어서 클라이언트에서 수행.

namespace Utilities.FSM
{
    [RequireComponent(typeof(StateMachine))]
    public abstract class State : MonoBehaviour
    {
        #region Fields 

        [SerializeField] protected GameObject m_Entity = null;

        [SerializeField] StateMachine m_StateMachine = null;

        bool m_isAddedToList = false;

        #endregion


        #region Properties

        public GameObject Entity { get { return m_Entity; } }
        public StateMachine stateMachine { get { return m_StateMachine; } }
        public bool isAddedToList { get { return m_isAddedToList; } }

        #endregion


        #region 에디터에서 호출하는 함수

        public void AddToFSMList()
        {
            m_isAddedToList = true;

            stateMachine.stateList.Add(this);
        }

        public void RemoveToFSMList()
        {
            m_isAddedToList = false;

            int index = stateMachine.stateList.FindLastIndex(go => (go == this));

            if(index != -1) 
                stateMachine.stateList.RemoveAt(index);
        }

        #endregion


        #region 순수가상함수

        public abstract void Enter();

        public abstract void Execute();

        public abstract void Exit();

        #endregion


        protected virtual void Reset()
        {
            if(m_StateMachine == null)
                m_StateMachine = GetComponent<StateMachine>();

            if(m_Entity == null)
                m_Entity = stateMachine.getEntity;

            //RemoveToFSMList();
        }
    }
}