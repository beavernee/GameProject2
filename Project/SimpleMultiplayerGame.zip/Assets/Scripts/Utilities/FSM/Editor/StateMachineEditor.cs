﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Utilities.FSM
{
    [CustomEditor(typeof(StateMachine))]
    public class StateMachineEditor : Editor
    {
        StateMachine Target;
        private State tempState;

        private void OnEnable()
        {
            Target = (StateMachine)target;
        }

        public override void OnInspectorGUI()
        {
            DrawInspector();
        }

        private void DrawInspector()
        {
            Target.IsShowedList = EditorGUILayout.Foldout(Target.IsShowedList, "상태목록");

            GUI.enabled = false;
            if (Target.IsShowedList)
            {
                for (int i = 0; i < Target.stateList.Count; i++)
                {
                    tempState = Target.stateList[i];

                    EditorGUILayout.ObjectField(tempState.GetType().ToString()
                                                , tempState
                                                , typeof(State)
                                                , false);
                }
            }

            EditorGUILayout.Separator();

            EditorGUILayout.ObjectField("이전상태", Target.previousState, typeof(State), false);
            EditorGUILayout.IntField("이전(인덱스)", Target.previousIndex);

            EditorGUILayout.Separator();

            EditorGUILayout.ObjectField("현재상태",Target.currentState, typeof(State),false);
            EditorGUILayout.IntField("현재(인덱스)", Target.currentIndex);

            EditorGUILayout.Separator();

            EditorGUILayout.ObjectField("전역상태", Target.globalState, typeof(State), false);
            EditorGUILayout.IntField("전역(인덱스)", Target.globalIndex);

            EditorGUILayout.Separator();

            ///
            /// 전역상태는 마지막 인덱스로 설정한다.
            ///
            EditorGUILayout.BeginHorizontal();

            GUI.enabled = (Target.globalState) ? false : true;
            if(GUILayout.Button("전역 상태 추가"))
            {
                BtnAddGlobal();
            }

            
            GUI.enabled = (Target.globalState) ? true : false;
            if (GUILayout.Button("전역 상태 삭제"))
            {
                BtnRemoveGlobal();
            }

            EditorGUILayout.EndHorizontal();
        }

        private void BtnAddGlobal()
        {
            int last_idx = Target.stateList.Count - 1;

            Target.globalState = Target.stateList[last_idx];
            Target.globalIndex = last_idx;
        }

        private void BtnRemoveGlobal()
        {
            Target.globalState = null;
            Target.globalIndex = -1;
        }
    }

}