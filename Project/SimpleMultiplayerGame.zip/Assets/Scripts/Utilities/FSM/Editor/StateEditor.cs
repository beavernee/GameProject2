﻿using UnityEngine;
using UnityEditor;

namespace Utilities.FSM
{
    [CustomEditor(typeof(State))]    
    public class StateEditor : Editor
    {
        State Target;
       
        protected virtual void OnEnable()
        {
            Target = (State)target;
        }

        protected virtual void DrawInspectorGUI()
        {
            GUI.enabled = false;
            EditorGUILayout.ObjectField("FSM 개체", Target.Entity, typeof(GameObject), false);
            EditorGUILayout.ObjectField("FSM", Target.stateMachine, typeof(StateMachine),false);
            EditorGUILayout.Separator();

            GUI.enabled = true;
            if (!Target.isAddedToList)
            {
                if(GUILayout.Button("Add to FSM List"))
                {
                    Target.AddToFSMList();
                }
            }
            else
            {
                if(GUILayout.Button("Remove to FSM List"))
                {
                    Target.RemoveToFSMList();
                }
            }

            serializedObject.ApplyModifiedProperties();
        }
    }
}
