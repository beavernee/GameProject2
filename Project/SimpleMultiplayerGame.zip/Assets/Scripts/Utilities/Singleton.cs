﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Utilities
{
    /// <summary>
    /// 싱글톤 클래스
    /// </summary>
    /// <typeparam name="T">싱글톤 타입</typeparam>
    public class Singleton<T> : MonoBehaviour where T : Singleton<T>
    {
        private static T s_instance;

        public static T s_Instance
        {
            get
            {
                if(s_instance == null)
                {
                    s_instance = FindObjectOfType<T>();

                    if (!s_instance)
                        MyDebug.LogError("오브젝트를 찾을 수 없습니다. ");
                }

                return s_instance;
            }

            protected set { s_instance = value; }
        }

        public static bool s_InstanceExists { get { return s_instance != null; } }

        protected virtual void Awake()
        {
            if (s_instance != null)
                Destroy(this.gameObject);

            else
            {
                s_Instance = (T)this;
            }
        }
    }
}