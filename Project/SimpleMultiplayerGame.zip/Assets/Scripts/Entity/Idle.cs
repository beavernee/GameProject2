﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Utilities.FSM;

public class Idle : State {

    public int count = 0;

    public int i;

    private void Awake()
    {
        // 상태전이를 위한 인덱스
        i = stateMachine.stateList.FindIndex(g => g.GetType().Equals(stateMachine.stateList[1].GetType()));
    }

    public override void Enter()
    {
        Debug.Log("Idle로 진입");
        GetComponentInChildren<Renderer>().material.color = Color.red;
    }

    public override void Execute()
    {
        count++;

        if (count > 30)
        {
            count = 0;
            stateMachine.ChangeState(i);
        }
    }

    //[ClientRpc]
    private void RpcTestRenderChange(Color color)
    {
        GetComponent<Renderer>().material.color = color;
    }

    public override void Exit()
    {
        Debug.Log("Idle 퇴출");
    }

}
