﻿using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;
using AntGame;

// Note.
// 4.21 SoccerTeam의 상태를 설계
// state를 추상클래스로 설계를 했었다.
// m_Entity는 GameObject로 설정을 했음
// C#에서는 다운캐스팅이 활성화되지않음
// 각 상태에 SoccerTeam을 캐싱해두고 사용해야한다.
//
public class Defending : State
{
    // 각 상태에 SoccerTeam을 캐싱해두고 사용해야한다.
    SoccerTeam Team;

    [SerializeField] private int next_state;

    protected override void Reset()
    {
        base.Reset();

        Team = m_Entity.GetComponent<SoccerTeam>();
    }

    #region Functions
    public override void Enter()
    {
        ChangePlayerHomeRegions();
    }

    public override void Execute()
    {
        if (SoccerBall.s_Instance.Owner.Team != this.Team)
            Team.stateMachine.ChangeState(next_state);
    }

    public override void Exit()
    {
        
    }

    private void ChangePlayerHomeRegions()
    {
        for (int i = 0; i < Team.Members.Count; i++)
            Team.Set_player_home_region(i);
    }
    #endregion

}
