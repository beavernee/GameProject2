﻿using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;
using AntGame;

namespace AntGame.Entity.FSM
{
    public class Attacking : State
    {
        SoccerTeam Team;

        protected override void Reset()
        {
            base.Reset();

            Team = m_Entity.GetComponent<SoccerTeam>();
        }

        #region Functions
        public override void Enter()
        {

        }

        public override void Execute()
        {

        }

        public override void Exit()
        {

        }
        #endregion
    }
}