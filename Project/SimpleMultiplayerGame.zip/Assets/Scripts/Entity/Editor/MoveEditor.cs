﻿using System.Collections.Generic;
using UnityEditor;
using Utilities.FSM;

[CustomEditor(typeof(Move))]
public class MoveEditor : StateEditor  {

    public override void OnInspectorGUI()
    {
        DrawInspectorGUI();
        base.OnInspectorGUI();
    }

}
