﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Utilities.FSM;

[CustomEditor(typeof(Idle))]
public class IdleEditor : StateEditor {

    public override void OnInspectorGUI()
    {
        DrawInspectorGUI();
        base.OnInspectorGUI();
    }
}
