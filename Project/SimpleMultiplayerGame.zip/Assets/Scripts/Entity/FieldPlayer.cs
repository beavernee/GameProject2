﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity
{
    [RequireComponent(typeof(StateMachine))]
    public class FieldPlayer : PlayerBase, IFSM_object
    {
        [SerializeField] StateMachine m_stateMachine;

        public StateMachine stateMachine
        {
            get { return m_stateMachine; }
            set { m_stateMachine = value; }
        }

        public GameObject getGameObject
        {
            get { return gameObject; }
        }

        protected override void Initailize()
        {
            base.Initailize();

            m_stateMachine = GetComponent<StateMachine>();
            m_stateMachine.Initialize();
        }


    }
}