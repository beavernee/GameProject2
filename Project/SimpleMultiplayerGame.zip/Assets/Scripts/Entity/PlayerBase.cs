﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Networking;

//NetworkBehaviour를 고려해서 설계한다.
//RequireComponent(typeof(NetworkTransform))

namespace AntGame.Entity
{
    //[RequireComponent(typeof(PlayerMovement))]
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(Rigidbody))]
    public abstract class PlayerBase : MonoBehaviour
    {
        public enum Player_Role { Goal_Keeper, Attakcer, Defender }

        #region Fields

        [SerializeField] protected Player_Role m_PlayerRole;

        [SerializeField] protected SteeringBehaviors m_Steering;
        [SerializeField] protected SoccerTeam m_Team;
        
        // AI 이동처리
        [SerializeField] protected NavMeshAgent m_NavMeshAgent;

        // 힘 테스트
        public float shootForce;


        //Note.region 객체를 가리키고 있는건 비효율?
        //일단 그대로 사용
        public Region homeRegion;
        public Region attackRegion;

        #endregion

        //정리는 나중에한다
        public PlayerMovement Movement;

        /// <summary>
        /// 선수의 팀정보를 접근하기 위한 프로퍼티 항상 필요
        /// </summary>
        public SoccerTeam Team {
            get { return m_Team; }
            set { m_Team = value; }
        }

        public NavMeshAgent getNavMeshAgent {
            get { return m_NavMeshAgent; }
        }

        /// <summary>
        /// SoccerBall의 소유를 변경시켜주는 함수
        /// </summary>
        public void SetOwnerOfTheBall(SoccerBall _ball = null)
        {
            //Team.ControllingPlayer = (_ball != null) ? this : null;

            Team.IsAuthorizedBall = true;
            Team.sb = _ball;

            Team.Oppenent.IsAuthorizedBall = false;
            Team.Oppenent.sb = null;
        }

        /// <summary>
        /// 공에 대한 명령 (슛, 패스)
        /// </summary>
        public void Kick()
        {
            
            Team.sb.Kicked(Team.sb.transform.forward, shootForce);

            Team.IsAuthorizedBall = false;
            Team.sb = null;
        }

        /// <summary>
        /// 이동을 위한 위치지정
        /// </summary>
        [ContextMenu("Return")]
        public void Set_home_region()
        {
            getNavMeshAgent.destination
                = homeRegion.transform.position;
        }

        // 여기에 적합하지 않은 부분
        public void RotateHeadingToFacePosition(Vector3 _position)
        {
            Vector3 toTarget = Vector3.Normalize(_position - transform.position);

            // 내적
            // transform.forward를 이용
            float dot = Vector3.Dot(toTarget, transform.forward);

            float angle = Mathf.Acos(dot);

            if (angle < 0.00001)
                return;

            //로컬좌표계로 가져온다.
            Vector3 convert_to_local = transform.InverseTransformVector(toTarget);

            transform.Rotate(0
                , (convert_to_local.x >= 0) ? angle * Mathf.Rad2Deg * Time.deltaTime
                                          : -angle * Mathf.Rad2Deg * Time.deltaTime
                , 0);
        }

        protected virtual void Reset()
        {
            Initailize();
        }

        protected virtual void Awake()
        {
            if(Movement == null) Movement = GetComponent<PlayerMovement>();
        }

        protected virtual void Initailize()
        {
            m_NavMeshAgent = GetComponent<NavMeshAgent>();
            
            // 속성 변경
            m_NavMeshAgent.baseOffset = 0.0f;
            m_NavMeshAgent.height = 0.1f;

            // 자식오브젝트에 조종행동 객체를 만든다?
            // FSM은 어디서 관리할것인가??

            if (!GetComponentInChildren<SteeringBehaviors>())
            {
                GameObject go = new GameObject("SteeringBehaviors");
                go.AddComponent<SteeringBehaviors>();
                go.transform.SetParent(gameObject.transform);

                m_Steering = go.GetComponent<SteeringBehaviors>();
                m_Steering.setPlayerBase = this;
            }
            // Rigidbody의 물리를 비활성화해준다.
            // NavMeshAgent를 활용하기 위해서임
            GetComponent<Rigidbody>().isKinematic = true;
        }
    }
}