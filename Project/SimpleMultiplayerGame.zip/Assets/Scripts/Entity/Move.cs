﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Utilities.FSM;

// 4/15 생각적기
// string 배열을 만들어서 캐싱해둔 후에  참조?
// 여러상태로 전이될 수 있을때

public class Move : State
{
    public int count = 0;

    public int i;

    [ContextMenu("Awake")]
    private void Awake()
    {
        // 상태전이를 위한 인덱스
        int index = stateMachine.stateList.FindIndex(g => g.GetType().Equals(stateMachine.stateList[0].GetType()));
        i = index;
    }

    public override void Enter()
    {
        Debug.Log("Move로 진입");

        //RpcTestRenderChange(Color.blue);
        GetComponentInChildren<Renderer>().material.color = Color.blue;
    }

    public override void Execute()
    {
        count++;
        
        if (count > 30)
        {
            count = 0;
            stateMachine.ChangeState(i);
        }
    }

    public override void Exit()
    {
        Debug.Log("Move퇴출");
    }
}

