﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class NewBehaviourScript : MonoBehaviour {

    public List<TestClass> testList;

    private void Reset()
    {
        this.hideFlags = HideFlags.None;

    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    [ContextMenu("Test")]
    private void Test()
    {
        testList.Add(null);
    }

    [ContextMenu("Test2")]
    private void Test2()
    {
        testList.Add(new TestClass());
    }
}

[System.Serializable]
public class TestClass
{
    public int n;

    public TestClass()
    {
        n = Random.Range(0, 10);
    }
}