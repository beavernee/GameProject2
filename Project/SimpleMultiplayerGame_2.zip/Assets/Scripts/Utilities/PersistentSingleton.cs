﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Utilities
{
    /// <summary>
    /// 영구적인 싱글톤 씬이 바껴도 항상 생존
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PersistentSingleton<T> : Singleton<T>  where T : Singleton<T>{

        protected override void Awake()
        {
            base.Awake();

            DontDestroyOnLoad(this.gameObject);
        }
    }
}