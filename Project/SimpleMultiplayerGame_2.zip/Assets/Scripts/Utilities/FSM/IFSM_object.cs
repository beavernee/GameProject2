﻿using System.Collections.Generic;
using UnityEngine;

namespace Utilities.FSM
{
    /// <summary>
    /// 다중상속을 구현하기 위해서는 인터페이스를 이용
    /// </summary>
    public interface IFSM_object
    {
        // 유한상태기계의 대한 프로퍼티를 갖게 한다.
        StateMachine stateMachine {
            get; set;
        }
    }

}