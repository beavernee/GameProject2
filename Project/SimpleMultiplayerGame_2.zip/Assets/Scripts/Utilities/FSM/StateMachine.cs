﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace Utilities.FSM
{
    [DisallowMultipleComponent]
    [AddComponentMenu("AntGame/StateMachine")]
    public class StateMachine : MonoBehaviour
    {
        #region Fields

        [SerializeField] State m_GlobalState = null;
        [SerializeField] State m_CurrentState = null;
        [SerializeField] State m_PreviousState = null;

        [SerializeField] List<State> m_stateList = new List<State>();
        
        [SerializeField] int m_currentIndex = -1;
        [SerializeField] int m_previousIndex = -1;
        [SerializeField] int m_globalIndex = -1;
        
        #endregion


        #region Properties

        public bool IsShowedList { get; set; }

        public State currentState
        {
            get { return m_CurrentState; }
            set { m_CurrentState = value; }
        }

        public State previousState
        {
            get { return m_PreviousState; }
            set { m_PreviousState = value; }
        }

        public State globalState
        {
            get { return m_GlobalState; }
            set { m_GlobalState = value; }
        }

        public List<State> stateList
        {
            get { return m_stateList; }
        }

        public int currentIndex
        {
            get { return m_currentIndex; }
            protected set { m_currentIndex = value; }
        }

        public int previousIndex
        {
            get { return m_previousIndex; }
            protected set { m_previousIndex = value; }
        }

        public int globalIndex
        {
            get { return m_globalIndex; }
            set { m_globalIndex = value; }
        }

        #endregion

        #region Fuctions

        /// <summary>
        /// [ClientRpc] 서버에서 호출해서 클라이언트에서 수행
        /// </summary>
        /// <param name="i">stateList[i]의 인덱스</param>
        public void ChangeState(int i)
        {
            previousIndex = currentIndex;

            if (currentState != null)
            {
                previousState = currentState;
                currentState.Exit();
            }

            currentIndex = i;
            currentState = stateList[i];

            currentState.Enter();
        }
        
        public void RevertToPreviousState()
        {
            ChangeState(previousIndex);
        }
        
        public void EveryFrame()
        {
            if (m_GlobalState) m_GlobalState.Execute();

            if (m_CurrentState) m_CurrentState.Execute();
        }

        #endregion

    }
}