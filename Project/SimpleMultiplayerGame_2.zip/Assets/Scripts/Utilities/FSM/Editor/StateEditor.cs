﻿using UnityEngine;
using UnityEditor;

namespace Utilities.FSM
{
    [CustomEditor(typeof(State))]    
    public abstract class StateEditor : Editor
    {
        State _Target;
       
        protected virtual void OnEnable()
        {
            _Target = (State)target;
        }

        protected virtual void DrawInspectorGUI()
        {
            GUI.enabled = false;
            EditorGUILayout.ObjectField("FSM", _Target.stateMachine, typeof(StateMachine),false);
            EditorGUILayout.Separator();

            GUI.enabled = true;
            DrawButton();
        }

        protected virtual void DrawButton()
        {
            int idx = _Target.stateMachine.stateList.FindIndex(g => g.GetType().Equals(_Target.GetType()));

            if (idx == -1)
            {
                if (GUILayout.Button("Add to FSM List"))
                {
                    _Target.AddToFSMList();
                }
            }
            else
            {
                if (GUILayout.Button("Remove to FSM List"))
                {
                    _Target.RemoveToFSMList();
                }
            }
        }
    }
}
