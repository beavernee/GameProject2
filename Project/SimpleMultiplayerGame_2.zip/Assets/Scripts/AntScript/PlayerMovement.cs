﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame
{
    public class PlayerMovement : MonoBehaviour
    {
        public float speed = 1f;
        public float turnSpeed = 120f;

        public Vector3 m_DesiredDirection;

        private Rigidbody m_Rigidbody;

        public bool isMoving
        {
            get { return m_DesiredDirection.sqrMagnitude > 0.01f; }
        }

        public void SetDesiredMovementDirection(Vector3 moveDir)
        {
            m_DesiredDirection = moveDir;
            
            if (m_DesiredDirection.sqrMagnitude > 1)
            {
                m_DesiredDirection.Normalize();
            }
        }

        /// <summary>
        /// 이동 및 회전
        /// </summary>
        private void Move()
        {
            m_Rigidbody.position = m_Rigidbody.position + m_DesiredDirection * speed * Time.deltaTime;
            transform.position = m_Rigidbody.position;
        }

        private void Turn()
        {
            float desiredAngle = 90 - Mathf.Atan2(m_DesiredDirection.z, m_DesiredDirection.x) * Mathf.Rad2Deg;
            Quaternion desiredRotation = Quaternion.Euler(0f, desiredAngle, 0f);

            m_Rigidbody.rotation = Quaternion.RotateTowards(m_Rigidbody.rotation, desiredRotation, turnSpeed * Time.deltaTime);
            transform.rotation = m_Rigidbody.rotation;
        }

        #region MonoBehaviour 이벤트함수
        private void Awake()
        {
            m_Rigidbody = GetComponent<Rigidbody>();
        }

        private void Update()
        {
            if(isMoving)
            {
                Turn();
                Move();
            }
        }
        #endregion

    }
}
