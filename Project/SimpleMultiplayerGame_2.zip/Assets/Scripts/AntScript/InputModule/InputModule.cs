﻿using System;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;
using AntGame.Manager.GameManager;

namespace AntGame
{
    public abstract class InputModule : MonoBehaviour
    {
        protected PlayerInput playerInput { get; set; }

        protected abstract void MovementInput();

        protected abstract void ShootInput();

        protected abstract void PassInput();

        protected void SetDesiredMovementDirection(Vector3 _moveDir)
        {
            var refControllingPlayer = playerInput.Team.ControllingPlayer;

            if (refControllingPlayer)
                refControllingPlayer.Movement.SetDesiredMovementDirection(_moveDir);
        }

        protected void Shoot(GameObject _target, bool _isShooting = true)
        {
            if (playerInput.Team.IsAuthorizedBall)
                playerInput.Team.ControllingPlayer.Kick(_target, _isShooting);
        }

        protected void ChangeControllingPlayer(PlayerBase _target)
        {
            playerInput.Team.ControllingPlayer = _target;
        }

        /// <summary>
        /// 
        /// </summary>
        protected void CheckPassPossibleTo(int _memberIdx, PlayerBase _refcontrol )
        {
            if (SoccerBall.s_Instance.Owner == _refcontrol)
            {
                if(!GameManager.s_Instance.IsStarted)
                {
                    if (playerInput.Team.IsKickOffbyTeam)
                        GameManager.s_Instance.PlayStart();
                }

                Shoot(playerInput.Team.Members[_memberIdx].gameObject, false);
                ChangeControllingPlayer(playerInput.Team.Members[_memberIdx]);
            }
            else
                ChangeControllingPlayer(playerInput.Team.Members[_memberIdx]);
        }


        protected virtual void Awake()
        {
            playerInput = GetComponent<PlayerInput>();
        }

        /// KickOff에서 처리하는 것과
        /// Playing에서 처리하는 것은 다른처리
        protected virtual void Update()
        {
            switch (GameManager.s_Instance.state)
            {
                // 킥오프상태 일 때
                case EGameState.KickOff:
                    PassInput();
                    break;

                case EGameState.Playing:
                    MovementInput();
                    ShootInput();
                    PassInput();
                    break;

                case EGameState.Goal:
                    break;
            }
        }
    }
}