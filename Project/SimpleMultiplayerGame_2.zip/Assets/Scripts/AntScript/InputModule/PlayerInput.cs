﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame
{
    // 변경하게 될 클래스
    public class PlayerInput : MonoBehaviour
    {
        public InputModule Module;

        public SoccerTeam Team;

        private void Awake()
        {
            if (!Module) Module = GetComponent<InputModule>();

            if (!Team) Team = GetComponent<SoccerTeam>();
        }
    }
}