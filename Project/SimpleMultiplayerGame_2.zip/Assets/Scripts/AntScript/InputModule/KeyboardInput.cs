﻿using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;
using AntGame.Manager.GameManager;

namespace AntGame
{
    public class KeyboardInput : InputModule
    {
        protected override void MovementInput()
        {
            //float h = Input.GetAxis("Horizontal");
            //float v = Input.GetAxis("Vertical");

            float h = 0.0f; float v = 0.0f;

            if (playerInput.Team.Color == TeamColor.Red)
            {
                if (Input.GetKey(KeyCode.W))
                {
                    v = 1;
                }

                if (Input.GetKey(KeyCode.D))
                {
                    h = 1;
                }

                if (Input.GetKey(KeyCode.S))
                {
                    v = -1;
                }

                if (Input.GetKey(KeyCode.A))
                {
                    h = -1;
                }
            }
            
            if (playerInput.Team.Color == TeamColor.Blue)
            {
                if (Input.GetKey(KeyCode.UpArrow))
                {
                    v = 1;
                }

                if (Input.GetKey(KeyCode.RightArrow))
                {
                    h = 1;
                }

                if (Input.GetKey(KeyCode.DownArrow))
                {
                    v = -1;
                }

                if (Input.GetKey(KeyCode.LeftArrow))
                {
                    h = -1;
                }
            }

            Vector3 desiredDir = new Vector3(h, 0, v).normalized;

            SetDesiredMovementDirection(desiredDir);
        }

        protected override void ShootInput()
        {
            if(playerInput.Team.Color == TeamColor.Red)
            {
                if(Input.GetKeyDown(KeyCode.LeftShift))
                {
                    if (playerInput.Team.ControllingPlayer.Role != PlayerBase.Player_Role.Goal_Keeper)
                    {
                        Shoot(playerInput.Team.OppenentGoal.tmpDummy);
                        Debug.Log("Red Team Shoot");
                    }
                }
            }
            if (playerInput.Team.Color == TeamColor.Blue)
            {
                if(Input.GetKeyDown(KeyCode.RightShift))
                {
                    if (playerInput.Team.ControllingPlayer.Role != PlayerBase.Player_Role.Goal_Keeper)
                    {
                        Shoot(playerInput.Team.OppenentGoal.tmpDummy);
                        Debug.Log("Red Team Shoot");
                    }
                }
            }
        }

        protected override void PassInput()
        {
            int cntIdx = playerInput.Team.ControllingIndex;
            PlayerBase refControl = playerInput.Team.ControllingPlayer;

            if (playerInput.Team.Color == TeamColor.Red)
            {
                // 1번 선수에게 
                if (Input.GetKeyDown(KeyCode.Alpha1))
                {
                    if (cntIdx == 0)
                        return;

                    CheckPassPossibleTo(0, refControl);
                }

                // 2번 선수에게
                else if(Input.GetKeyDown(KeyCode.Alpha2))
                {
                    if (cntIdx == 1)
                        return;

                    CheckPassPossibleTo(1, refControl);
                }

                // 3번 선수에게
                else if(Input.GetKeyDown(KeyCode.Alpha3))
                {
                    if (cntIdx == 2)
                        return;

                    CheckPassPossibleTo(2, refControl);
                }

                // 4번 선수에게 (골키퍼)
                else if(Input.GetKeyDown(KeyCode.Alpha4))
                {
                    if (cntIdx == 3)
                        return;

                    // 팀상태가 공격일때만 키퍼에게 패스를 할 수 있다.
                    if(playerInput.Team.state == ETeamState.Attacking)
                        CheckPassPossibleTo(3, refControl);
                }
            }

            if (playerInput.Team.Color == TeamColor.Blue)
            {
                // 1번 선수에게 
                if (Input.GetKeyDown(KeyCode.H))
                {
                    if (cntIdx == 0)
                        return;

                    CheckPassPossibleTo(0, refControl);
                }

                // 2번 선수에게
                else if (Input.GetKeyDown(KeyCode.J))
                {
                    if (cntIdx == 1)
                        return;

                    CheckPassPossibleTo(1, refControl);
                }

                // 3번 선수에게
                else if (Input.GetKeyDown(KeyCode.K))
                {
                    if (cntIdx == 2)
                        return;

                    CheckPassPossibleTo(2, refControl);
                }

                // 4번 선수에게 (골키퍼)
                else if (Input.GetKeyDown(KeyCode.L))
                {
                    if (cntIdx == 3)
                        return;

                    // 팀상태가 공격일때만 키퍼에게 패스를 할 수 있다.
                    if (playerInput.Team.state == ETeamState.Attacking)
                        CheckPassPossibleTo(3, refControl);
                }
            }
        }
    }
}