﻿using System;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Entity;
using Utilities.FSM;

/// Note
/// 팀이 공의 권한을 가지고 있고, ControllingPlayer기준으로 슛을 하게 설계
/// 
namespace AntGame
{
    public enum TeamColor
    {
        Red,
        Blue,
    }

    // 이것에 접근해서 AI의 상태를 변경시킨다?
    public enum ETeamState
    {
        None,
        KickOff,
        Attacking,
        Defending
    }

    [RequireComponent(typeof(StateMachine))]
    [DisallowMultipleComponent]
    public class SoccerTeam : MonoBehaviour, IFSM_object
    {   
        #region Fields
        public GameObject DummyObject; // 최적의경로찾기위한 더미오브젝트

        [SerializeField] TeamColor m_Color;

        [SerializeField] StateMachine m_StateMachine;

        [SerializeField] List<PlayerBase> m_PlayerList;

        [SerializeField] SoccerTeam m_Oppenent;

        [SerializeField] Goal m_HomeGoal;
        [SerializeField] Goal m_OppenentGoal;

        //Note. 테스트용 삭제해도됨 프로퍼티도 수정해야한다.
        //완벽해지면 지우고 프로퍼티
        [SerializeField] SoccerBall m_Ball;

        public ETeamState state = ETeamState.None;

        /// <summary>
        /// 핵심 플레이어
        /// </summary>
        [SerializeField] PlayerBase m_PlayerClosestToBall = null;  //공에 가장 가까운 선수
        [SerializeField] PlayerBase m_ControllingPlayer = null;     //제어하는 선수  플레이어 컨트롤러가 작동하는 선수가 될 것이며, 축구공에 명령을 내릴 수 있는 선수이다.
        [SerializeField] PlayerBase m_SupportingPlayer = null;     //지원하는 선수  공격수로 부터 멀리 떨어진 유용한 위치로 움직인다.

        [SerializeField] private int m_controllingIndex = -1;

        public int ControllingIndex { get { return m_controllingIndex; } }

        #endregion

        #region Properties
        
        //Note. 아직은 없어도 된다.
        public bool IsKickOffbyTeam { get; set; }

        /// <summary>
        /// 팀이 공의 권한을 갖고 있는지 체크해주는 프로퍼티
        /// </summary>
        public bool IsAuthorizedBall { get; set; }

        public SoccerBall sb //프로퍼티명 대충해놓음
        {
            get { return m_Ball; } set { m_Ball = value; }
        }
        
        public SupportSpotCalculator SupportSpotCalc { get; set; }

        public TeamColor Color { get { return m_Color; } }

        public List<PlayerBase> Members {
            get { return m_PlayerList; }
        }

        public SoccerTeam Oppenent {
            get { return m_Oppenent; }
        }

        public Goal HomeGoal { get { return m_HomeGoal; } }
        public Goal OppenentGoal { get { return m_OppenentGoal; } }

        // 핵심로직
        public PlayerBase ControllingPlayer {
            get { return m_ControllingPlayer; }
            set {
                m_ControllingPlayer = value;

                for (int i = 0; i < Members.Count; i++)
                {
                    if(Members[i] == m_ControllingPlayer)
                    {
                        m_controllingIndex = i;
                        break;
                    }
                }
                //MyDebug.Log("ControllingPlayer Index = " + m_controllingIndex);
            }
        }

        public PlayerBase PlayerClosestToBall
        {
            get { return m_PlayerClosestToBall; }
            set { m_PlayerClosestToBall = value; }
        }

        public PlayerBase SupportingPlayer
        {
            get { return m_SupportingPlayer; }
            set { m_SupportingPlayer = value; }
        }

        /// <summary>
        /// IFSM_object 인터페이스 구현
        /// </summary>
        public StateMachine stateMachine {
            get { return m_StateMachine; }
            set { m_StateMachine = value; }
        }

        /// <summary>
        /// 지원지점을 얻기위한 프로퍼티
        /// </summary>
        public Vector3 GetSupportSpot
        {
            get { return SupportSpotCalc.GetBestSupportingSpot(); }
        }

        #endregion

        #region Functions

        /// <summary>
        /// KickOff 관련된 함수
        /// </summary>

        // Kick-off가 선공일 때,
        public void PreemptiveKickOff()
        {
            var refPitch = SoccerPitch.s_Instance;

            if(Color == TeamColor.Blue)
            { 
                for(int i = 0; i < Members.Count; i++)
                {
                    int _attack_idx = Members[i].attackKickOff_idx;
                    Members[i].transform.position = refPitch.Regions[_attack_idx].position;

                    Members[i].transform.LookAt(Vector3.zero);
                }
            }
            else
            {
                // SoccerPitch::Regions 인덱스를 반대로 접근
                for (int i = 0; i < Members.Count; i++)
                {
                    int _attack_idx = Members[i].attackKickOff_idx;
                    int maxCount = refPitch.Regions.Count - 1;
                    Members[i].transform.position = refPitch.Regions[maxCount - _attack_idx].position;

                    Members[i].transform.LookAt(Vector3.zero);
                }
            }
        }

        // Kick-off가 후공일 때,
        public void NotPreemptiveKickOff()
        {
            var refPitch = SoccerPitch.s_Instance;

            if(Color == TeamColor.Blue)
            {
                for (int i = 0; i < Members.Count; i++)
                {
                    int _defending_idx = Members[i].defendKickOff_idx;
                    Members[i].transform.position = refPitch.Regions[_defending_idx].position;

                    Members[i].transform.LookAt(Vector3.zero);
                }
            }
            else
            {
                // SoccerPitch::Regions 인덱스를 반대로 접근
                for (int i = 0; i < Members.Count; i++)
                {
                    int _defending_idx = Members[i].defendKickOff_idx;
                    int maxCount = refPitch.Regions.Count - 1;
                    Members[i].transform.position = refPitch.Regions[maxCount - _defending_idx].position;

                    Members[i].transform.LookAt(Vector3.zero);
                }
            }
        }


        public void ReturnAllFieldPlayersToHome()
        {
            for (int i = 0; i < Members.Count; i++)
            {
                if (Members[i].Role != PlayerBase.Player_Role.Goal_Keeper)
                {
                    Members[i].SetAIState();
                }
            }
        }


        public bool IsPassSafeFromAllOpponents(Vector3 from, Vector3 target, PlayerBase receiver)
        {
            for(int i = 0; i < Oppenent.Members.Count; i++)
            {
                if (!IsPassSafeFromOpponent(from, target, receiver, Oppenent.Members[i]))
                {
                    return false;
                }
            }

            return true;
        }

        public bool IsPassSafeFromOpponent(Vector3 from, Vector3 target, PlayerBase receiver, PlayerBase opp, float passingForce = 0)
        {
            // 더미오브젝트를 From위치에 설정 및 Target을 바라보게 한다.
            DummyObject.transform.position = from;
            DummyObject.transform.LookAt(target);

            Vector3 convertToLocal = DummyObject.transform.InverseTransformPoint(opp.transform.position);

            if (convertToLocal.z < 0)
                return true;

            if(Vector3.Distance(from, target) < Vector3.Distance(from, opp.transform.position))
            {
                if (receiver)
                {
                    if (Vector3.Distance(target, opp.transform.position) 
                        >  Vector3.Distance(target, receiver.transform.position))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 볼과 인접한 플레이어 계산하기
        /// </summary>
        private void CalculateClosestPlayerToBall()
        {
            float closetSoFar = float.MaxValue;

            for(int i = 0; i < Members.Count; i++)
            {
                // 조종선수는 검사 및 키퍼는 제외한다.
                if (Members[i] != ControllingPlayer && Members[i].Role != PlayerBase.Player_Role.Goal_Keeper)
                {
                    Vector3 distanceVector = SoccerBall.s_Instance.gameObject.transform.position - Members[i].transform.position;
                    float dist = Vector3.SqrMagnitude(distanceVector);

                    if (dist < closetSoFar)
                    {
                        closetSoFar = dist;

                        m_PlayerClosestToBall = Members[i];
                    }
                }
            }
        }

        // 아직 사용안함
        public void AddPlayerList(PlayerBase player)
        {
            m_PlayerList.Add(player);
        }

        #endregion

        #region MonoBehaviour 이벤트함수

        private void Reset()
        {
            m_StateMachine = GetComponent<StateMachine>();
        }

        private void Awake()
        {
            if (!m_StateMachine) m_StateMachine = GetComponent<StateMachine>();
        }

        private void Update()
        {
            CalculateClosestPlayerToBall();

            if (stateMachine.stateList.Count > 0)
                stateMachine.EveryFrame(); 
        }

        #endregion
    }
}
