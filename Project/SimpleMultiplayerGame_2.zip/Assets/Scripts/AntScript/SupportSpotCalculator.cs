﻿using System.Collections.Generic;
using UnityEngine;

namespace AntGame
{
    [DisallowMultipleComponent]
    public class SupportSpotCalculator : MonoBehaviour
    {
        [SerializeField] List<Region> m_Spots = new List<Region>();

        [SerializeField] bool m_isReady;
        [SerializeField] float m_fTime;
        [SerializeField] float m_fNextUpdateTime = 1.0f;

        bool isSettingSupportSpot = false;

        public SoccerTeam Team { get; private set; }
        public List<Region> Spots { get { return m_Spots; } }
        public Region BestSupportSpot { get; private set; }
        

        /// <summary>
        /// 최고의 위치를 결정해주는 기능
        /// </summary>
        /// <returns></returns>
        public Vector3 DetermineBestSupportingPosition()
        {
            //Note. 이부분을 수정해준다.
            // only update the spots every few frames ?? 
            if (!m_isReady && isSettingSupportSpot)
            {
                m_isReady = true;

                return BestSupportSpot.position;
            }

            isSettingSupportSpot = false;
            BestSupportSpot = null;

            float bestScoreSoFar = 0.0f;

            for (int i = 0; i < Spots.Count; i++)
            {
                Spots[i].score = 1.0f;

                // 검사1. 공의 위치에서 이 위치까지 안전하게 패스할 수 있는지를 결정
                if (Team.IsPassSafeFromAllOpponents(Team.ControllingPlayer.transform.position,
                                                Spots[i].position, null))
                {
                    Spots[i].score += 2.0f;
                }

                // 검사2. 이 지점이 제어 선수로부터 얼마나 떨어져 있는지를 계산한다.
                // 멀리 떨어져 있을수록 점수가 더 높으며, OptinalDistance보다 더 먼 거리는 점수를 받지 못함.
                if (Team.SupportingPlayer)
                {
                    const float optimalDistance = 10.0f;

                    float dist = Vector3.Distance(Team.ControllingPlayer.transform.position,
                                                 Spots[i].position);

                    float temp = Mathf.Abs(optimalDistance - dist);

                    if(temp < optimalDistance)
                    {
                        // 거리를 정규화 하고 거기에 점수를 더한다.
                        Spots[i].score += 2.0f * (optimalDistance - temp) / optimalDistance;
                    }
                }

                // 이 지점이 지금까지 최고의 점수에 해당하는 지점인지를 검사한다.
                if(Spots[i].score > bestScoreSoFar)
                {
                    bestScoreSoFar = Spots[i].score;

                    BestSupportSpot = Spots[i];

                    if (!isSettingSupportSpot)
                        isSettingSupportSpot = true;
                }
            }

            return BestSupportSpot.position;
        }

        public Vector3 GetBestSupportingSpot()
        {
            if (isSettingSupportSpot)
            {
                return BestSupportSpot.position;
            }
            else
            {
                return DetermineBestSupportingPosition();
            }
        }

        #region MonoBehaviour 이벤트함수
        private void Awake()
        {
            Team = GetComponentInParent<SoccerTeam>();
            Team.SupportSpotCalc = this;

            BestSupportSpot = null;
        }

        private void FixedUpdate()
        {
            if (m_isReady)
            {
                if (m_fTime > m_fNextUpdateTime)
                {
                    m_fTime = 0.0f;

                    m_isReady = false;
                }

                m_fTime += Time.deltaTime;
            }
        }

        private void OnDrawGizmosSelected()
        {
            for (int i = 0; i < Spots.Count; i++)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawWireSphere(Spots[i].position, 0.2f);
            }
        }
        #endregion
    }
}