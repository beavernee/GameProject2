﻿using UnityEngine;
using UnityEditor;

namespace AntGame
{
    [CustomEditor(typeof(SoccerPitch))]
    public class PitchEditor : Editor
    {
        SoccerPitch Target;
        Region cntRegion;
        
        private void OnEnable()
        {
            Target = (SoccerPitch)target;
        }

        public override void OnInspectorGUI()
        {
            if (GUILayout.Button("Add New"))
            {
                // 기본생성자를 호출 
                Region temp = new Region();
                Target.Regions.Add(temp);
            }
            DrawRegionList();
        }

        private void DrawRegionList()
        {
            for(int i = 0; i < Target.Regions.Count; i++)
            {
                cntRegion = Target.Regions[i];

                EditorGUILayout.BeginHorizontal();
                if(GUILayout.Button("Expand"))
                {
                    cntRegion.toggle = !cntRegion.toggle;
                }

                EditorGUILayout.Separator();
                cntRegion.toggle = EditorGUILayout.Foldout(cntRegion.toggle, "Custom Region" + i.ToString());

                if (GUILayout.Button("Remove"))
                {
                    Target.Regions.Remove(cntRegion);
                    break;
                }

                EditorGUILayout.EndHorizontal();

                if (cntRegion.toggle)
                {
                    EditorGUILayout.Separator();
                    EditorGUILayout.Separator();
                    DrawVectorField();
                }
            }
        }

        private void DrawVectorField()
        {
            EditorGUILayout.BeginHorizontal();
            cntRegion.position = EditorGUILayout.Vector3Field("Vector Field", 
                                                            cntRegion.position);
            EditorGUILayout.EndHorizontal();
        }
    }
}
