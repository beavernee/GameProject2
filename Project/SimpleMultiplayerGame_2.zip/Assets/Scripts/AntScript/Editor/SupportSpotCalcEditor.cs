﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace AntGame
{
    [CustomEditor(typeof(SupportSpotCalculator))]
    public class SupportSpotCalcEditor : Editor
    {
        SupportSpotCalculator Target;
        Region cntRegion;

        private void OnEnable()
        {
            Target = (SupportSpotCalculator)target;
        }

        public override void OnInspectorGUI()
        {
            if(GUILayout.Button("Add New Spot"))
            {
                Region temp = new Region();
                Target.Spots.Add(temp);
            }
            DrawRegionList();
        }

        private void DrawRegionList()
        {
            for (int i = 0; i < Target.Spots.Count; i++)
            {
                cntRegion = Target.Spots[i];

                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Expand"))
                {
                    cntRegion.toggle = !cntRegion.toggle;
                }

                EditorGUILayout.Separator();
                cntRegion.toggle = EditorGUILayout.Foldout(cntRegion.toggle, "Custom Region" + i.ToString());

                if (GUILayout.Button("Remove"))
                {
                    Target.Spots.Remove(cntRegion);
                    break;
                }

                EditorGUILayout.EndHorizontal();

                if (cntRegion.toggle)
                {
                    EditorGUILayout.Separator();
                    EditorGUILayout.Separator();
                    DrawVectorField();

                    GUI.enabled = false;
                    DrawScoreField();
                    GUI.enabled = true;
                }
            }
        }

        private void DrawVectorField()
        {
            cntRegion.position = EditorGUILayout.Vector3Field("Vector3 Field",
                                                            cntRegion.position);
        }

        private void DrawScoreField()
        {
            EditorGUILayout.FloatField("Score", cntRegion.score);
        }
    }
}