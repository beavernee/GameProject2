﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity
{
    public enum EKeeperState
    {
        None,
        TendGoal,
        ReturnToHome,
        Intercept,
        Control,
    }

    [RequireComponent(typeof(StateMachine))]
    public class GoalKeeper : PlayerBase, IFSM_object
    {
        public EKeeperState state = EKeeperState.None;

        [SerializeField] StateMachine m_stateMachine;

        public StateMachine stateMachine
        {
            get { return m_stateMachine; }
            set { m_stateMachine = value; }
        }

        protected override void Initailize()
        {
            base.Initailize();

            m_stateMachine = GetComponent<StateMachine>();
        }

        public override void SetAIState()
        {
            stateMachine.ChangeState(0);
        }

        private void Start()
        {
            if (stateMachine.stateList.Count > 0)
                SetAIState();
        }

        private void Update()
        {
            if (stateMachine.stateList.Count > 0)
                stateMachine.EveryFrame();

            //Vector3 pointingToKeeper = this.transform.position - Team.HomeGoal.transform.position;

            //Debug.Log(pointingToKeeper);
        }
    }
}