﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using AntGame.Manager.GameManager;

//NetworkBehaviour를 고려해서 설계한다.
//RequireComponent(typeof(NetworkTransform))

namespace AntGame.Entity
{
    [RequireComponent(typeof(NavMeshAgent))] // -->  NavMeshAgent를 이용하므로 리지드바디 isKinematic 속성을 켜서 물리이용X
    [RequireComponent(typeof(Rigidbody))]
    public abstract class PlayerBase : MonoBehaviour
    {
        public enum Player_Role { Goal_Keeper, Attakcer, Defender }

        #region Fields

        [SerializeField] protected Player_Role m_PlayerRole;

        [SerializeField] protected SoccerTeam m_Team;
        
        // AI 이동처리
        [SerializeField] protected NavMeshAgent m_NavMeshAgent;

        // 힘 테스트
        public float shootForce;
        public float passForce;

        // KickOff Idx 설정
        [Header("킥오프 포지션")]
        public int attackKickOff_idx;
        public int defendKickOff_idx;

        // 공격 및 방어 idx 설정
        [Header("공격 및 방어 포지션")]
        public int attackPosition_idx;
        public int defendPosition_idx;
        #endregion

        public PlayerMovement Movement;

        #region Properties

        public Player_Role Role {
            get { return m_PlayerRole; }
        }

        /// <summary>
        /// 선수의 팀정보를 접근하기 위한 프로퍼티 항상 필요
        /// </summary>
        public SoccerTeam Team {
            get { return m_Team; }
            set { m_Team = value; }
        }

        public NavMeshAgent getNavMeshAgent {
            get { return m_NavMeshAgent; }
        }

        #endregion

        public bool IsClosetTeamMemberToBall
        {
            get { return Team.PlayerClosestToBall == this; }
        }

        /// <summary>
        /// SoccerBall의 소유를 변경시켜주는 함수
        /// </summary>
        public void SetOwnerOfTheBall(SoccerBall _ball = null)
        {
            //Team.ControllingPlayer = (_ball != null) ? this : null;
            Team.IsAuthorizedBall = true;
            Team.sb = _ball;

            Team.Oppenent.IsAuthorizedBall = false;
            Team.Oppenent.sb = null;
        }

        /// <summary>
        /// 공에 대한 명령 (슛, 패스)
        /// </summary>
        public void Kick(GameObject target, bool _isShooting)
        {
            Vector3 desiredDirection 
                = (target.transform.position - Team.sb.transform.position).normalized;

            // (PlayerBase의 정면, 원하는 방향)의 내적을 계산해본다,
            // 음수의 경우는, 뒤에있다는 의미가 된다,
            if (Vector3.Dot(desiredDirection, transform.forward) < 0)
            {
                // target.transform.position의 월드좌표를 PlayerBase 로컬좌표계로 전환시켜준다.
                Vector3 convertToLocal = transform.InverseTransformPoint(target.transform.position);

                if (convertToLocal.x > 0)
                    desiredDirection = transform.right;
                else
                    desiredDirection = -transform.right;
            }

            //Team.sb.Kicked( desiredDirection,
            //    _isShooting ? shootForce : passForce );

            if (_isShooting)
            {
                // ShootGauge의 currengGauge가 3일 때, 파워슛(1.5배로 설정) 하게 된다.
                Team.sb.Kicked(desiredDirection,
                    GameManager.s_Instance.GameSystemUI.shootGaugeUI.currentGauge == 3 ? 
                    shootForce * 1.5f : shootForce);
            }
            else
                Team.sb.Kicked(desiredDirection, passForce);

            Team.IsAuthorizedBall = false;
            Team.sb = null;
        }

        // LookAt 이용하는 것으로 수정
        public void RotateHeadingToFacePosition(Vector3 _position)
        {
            Vector3 toTarget = Vector3.Normalize(_position - transform.position);

            // 내적
            // transform.forward를 이용
            float dot = Vector3.Dot(toTarget, transform.forward);

            float angle = Mathf.Acos(dot);

            if (angle < 0.00001)
                return;

            //로컬좌표계로 가져온다.
            Vector3 convert_to_local = transform.InverseTransformVector(toTarget);

            transform.Rotate(0
                , (convert_to_local.x >= 0) ? angle * Mathf.Rad2Deg * Time.deltaTime
                                          : -angle * Mathf.Rad2Deg * Time.deltaTime
                , 0);
        }

        public abstract void SetAIState();
        
        protected virtual void Reset()
        {
            Initailize();
        }

        protected virtual void Awake()
        {
            if(Movement == null) Movement = GetComponent<PlayerMovement>();

            if (!GetComponent<Rigidbody>().isKinematic)
                GetComponent<Rigidbody>().isKinematic = true;
        }

        protected virtual void Initailize()
        {
            m_NavMeshAgent = GetComponent<NavMeshAgent>();
            
            // 속성 변경
            m_NavMeshAgent.baseOffset = 0.0f;
            m_NavMeshAgent.height = 0.1f;

            // 자식오브젝트에 조종행동 객체를 만든다?
            // FSM은 어디서 관리할것인가??
            if (!GetComponentInChildren<SteeringBehaviors>())
            {
                GameObject go = new GameObject("SteeringBehaviors");
                go.AddComponent<SteeringBehaviors>();
                go.transform.SetParent(gameObject.transform);

            }
            // Rigidbody의 물리를 비활성화해준다.
            // NavMeshAgent를 활용하기 위해서임
            GetComponent<Rigidbody>().isKinematic = true;
        }
    }
}