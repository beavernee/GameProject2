﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace AntGame.Entity
{
    // 필요없음 NavMeshAgent 이용하고 있으며, 복잡한 AI를 사용하지 않는다. 
    public class SteeringBehaviors : MonoBehaviour
    {
        public enum BehaviorType
        {
            Seek        = 0x0001,   //0001
            Arrive      = 0x0002,   //0010
            Pursuit     = 0x0004,   //0100

            // NavMeshAgent를 이용하면 상시 Arrive이기 때문에
            // Seek을 구현하려면 ?
            
            // 단순 AI이기 때문에 끼워넣기, 집단행동 AI는 필요없다.
            // Separation  = 0x00000004,   //00100
            // Interpose   = 0x00000010,   //10000 
        }

        [SerializeField] protected PlayerBase m_PlayerBase;

        [SerializeField] [EnumFlags] protected BehaviorType m_Flag;

        [SerializeField] protected Vector3 m_vTarget;

        public GameObject test;

        public PlayerBase setPlayerBase {
            set { m_PlayerBase = value; }
        }

        public Vector3 Target
        {
            get { return m_vTarget; }
            set { m_vTarget = value; }
        }

        private bool On(BehaviorType type) {
            return (m_Flag & type) == type;
        }
        
        public void SeekOn()    { m_Flag |= BehaviorType.Seek; }
        public void ArriveOn()  { m_Flag |= BehaviorType.Arrive; }
        public void PursuitOn() { m_Flag |= BehaviorType.Pursuit; }

        public void SeekOff()   { m_Flag ^= BehaviorType.Seek; }
        public void ArriveOff() { m_Flag ^= BehaviorType.Arrive; }
        public void PursuitOff(){ m_Flag ^= BehaviorType.Pursuit; }

        // 행동 타입에 맞게 구현
        
        // 찾기
        void Seek(Vector3 target)
        {

        }

        // 도착하기
        void Arrive(Vector3 target)
        {

        }

        // 추격하기
        void Pursuit()
        {

        }
        //m_vTarget = test.transform.position;
        //m_PlayerBase.getNavMeshAgent.destination = m_vTarget + Vector3.forward;
        //m_PlayerBase.getNavMeshAgent.SetDestination(m_PlayerBase.getNavMeshAgent.destination);
    }
}