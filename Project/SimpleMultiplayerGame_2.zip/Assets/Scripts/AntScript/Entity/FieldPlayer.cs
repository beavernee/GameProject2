﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity
{
    public enum EFieldPlayerState
    {
        None,
        Wait,
        ChaseBall,
        ReturnToHomeRegion,
        SupportAttacker,
        Control,
    }

    [RequireComponent(typeof(StateMachine))]
    public class FieldPlayer : PlayerBase, IFSM_object
    {
        public EFieldPlayerState state = EFieldPlayerState.None;

        [SerializeField] StateMachine m_stateMachine;

        public StateMachine stateMachine
        {
            get { return m_stateMachine; }
            set { m_stateMachine = value; }
        }

        protected override void Initailize()
        {
            base.Initailize();

            m_stateMachine = GetComponent<StateMachine>();
        }

        public override void SetAIState()
        {
            stateMachine.ChangeState(0);
        }

        private void Start()
        {
            if (stateMachine.stateList.Count > 0)
                SetAIState();
        }

        private void Update()
        {
            if (stateMachine.stateList.Count > 0)
                stateMachine.EveryFrame();
        }
    }
}