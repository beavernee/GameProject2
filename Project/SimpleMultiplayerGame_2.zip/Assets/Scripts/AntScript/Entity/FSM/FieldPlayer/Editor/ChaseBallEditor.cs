﻿using UnityEditor;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(ChaseBallState))]
    public class ChaseBallEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}