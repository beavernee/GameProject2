﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(SupportAttackerState))]
    public class SupportAttackerEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}
