﻿using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    /// <summary>
    /// 볼만 쫓아가게 설정해준다. 태클 기능은 나중에 생각한다.
    /// </summary>
    [AddComponentMenu("AntGame/FieldPlayer/FSM/ChaseBallState")]
    [DisallowMultipleComponent]
    public class ChaseBallState : FieldPlayerState
    {
        public override FieldPlayer Player { get; set; }

        float m_fPrevStoppingDistance;

        public override void Enter()
        {
            Player.state = EFieldPlayerState.ChaseBall;

            m_fPrevStoppingDistance = Player.getNavMeshAgent.stoppingDistance;
            Player.getNavMeshAgent.stoppingDistance = 0;
        }

        public override void Execute()
        {
            if (!Player.IsClosetTeamMemberToBall)
            {
                Player.stateMachine.ChangeState(0);
            }

            Player.getNavMeshAgent.SetDestination(SoccerBall.s_Instance.transform.position);
        }

        public override void Exit()
        {
            Player.getNavMeshAgent.stoppingDistance = m_fPrevStoppingDistance;
        }

        private void Awake()
        {
            Player = GetComponent<FieldPlayer>();
        }
    }
}