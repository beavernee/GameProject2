﻿using UnityEditor;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(RootAiState))]
    public class AIStateEditor : StateEditor
    {
        SerializedProperty waitProperty;
        SerializedProperty chaseBallProperty;
        SerializedProperty returnToHomeProperty;
        SerializedProperty supportAttackerProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            waitProperty = serializedObject.FindProperty("waitState");
            chaseBallProperty = serializedObject.FindProperty("chaseBallState");
            returnToHomeProperty = serializedObject.FindProperty("returnToHomeState");
            supportAttackerProperty = serializedObject.FindProperty("supportAttackerState");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(waitProperty);
            EditorGUILayout.PropertyField(chaseBallProperty);
            EditorGUILayout.PropertyField(returnToHomeProperty);
            EditorGUILayout.PropertyField(supportAttackerProperty);

            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }

        protected override void DrawButton()
        {
            RootAiState _Target = (RootAiState)target;

            int idx = _Target.stateMachine.stateList.FindIndex(g => g.GetType().Equals(_Target.GetType()));

            if (idx == -1)
            {
                if (GUILayout.Button("Add to FSM List"))
                {
                    _Target.AddToFSMList(true);
                }
            }
            else
            {
                if (GUILayout.Button("Remove to FSM List"))
                {
                    _Target.RemoveToFSMList();
                }
            }
        }
    }
}
