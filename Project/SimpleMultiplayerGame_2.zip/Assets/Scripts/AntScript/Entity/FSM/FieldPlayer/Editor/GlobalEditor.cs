﻿using UnityEngine;
using Utilities.FSM;
using UnityEditor;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(GlobalState))]
    public class GlobalEditor : StateEditor
    {
        SerializedProperty controlProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            controlProperty = serializedObject.FindProperty("controlState");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(controlProperty);
            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }
    }
}