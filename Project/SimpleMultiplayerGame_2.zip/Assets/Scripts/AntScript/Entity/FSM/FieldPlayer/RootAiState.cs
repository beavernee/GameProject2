﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/AIState")]
    [DisallowMultipleComponent]
    public class RootAiState : FieldPlayerState
    {
        public FieldPlayerState waitState = null;
        public FieldPlayerState chaseBallState = null;
        public FieldPlayerState returnToHomeState = null;      
        public FieldPlayerState supportAttackerState = null;

        public override FieldPlayer Player { get; set; }

        public int wait_idx { get; private set; }
        public int chaseBall_idx { get; private set; }
        public int returnToHome_idx { get; private set; }
        public int supportAttacker_idx { get; private set; }

        public override void Enter()
        {
            Player.state = EFieldPlayerState.None;

            Player.getNavMeshAgent.isStopped = false;
        }

        public override void Execute()
        {
            if (Player.Team.state == ETeamState.KickOff)
                Player.stateMachine.ChangeState(wait_idx);
            else
                Player.stateMachine.ChangeState(returnToHome_idx);
        }

        public override void Exit() { }

        protected virtual void Awake()
        {
            Player = GetComponent<FieldPlayer>();

            if (waitState == null) waitState = GetComponent<WaitState>();
            if (chaseBallState == null) chaseBallState = GetComponent<ChaseBallState>();
            if (returnToHomeState == null) returnToHomeState = GetComponent<ReturnToHomeState>();
            if (supportAttackerState == null) supportAttackerState = GetComponent<SupportAttackerState>();

            wait_idx = stateMachine.stateList.FindIndex(g => g.Equals(waitState));
            chaseBall_idx = stateMachine.stateList.FindIndex(g => g.Equals(chaseBallState));
            returnToHome_idx = stateMachine.stateList.FindIndex(g => g.Equals(returnToHomeState));
            supportAttacker_idx = stateMachine.stateList.FindIndex(g => g.Equals(supportAttackerState));

            if (wait_idx == -1 || chaseBall_idx == -1 || returnToHome_idx == -1 || supportAttacker_idx == -1)
                MyDebug.LogError("StateMachine 상태 리스트를 확인해주세요");
        }
    }
}