﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/ReturnToHomeState")]
    [DisallowMultipleComponent]
    public class ReturnToHomeState : FieldPlayerState
    {
        RootAiState aiState;

        public override FieldPlayer Player { get; set; }

        public override void Enter()
        {
            Player.state = EFieldPlayerState.ReturnToHomeRegion;

            var refPitch = SoccerPitch.s_Instance;

            if(Player.Team.state == ETeamState.Attacking)
            {
                if(Player.Team.Color == TeamColor.Blue)
                {
                    Player.getNavMeshAgent.destination = refPitch.Regions[Player.attackPosition_idx].position;
                }
                else
                {
                    int maxCount = refPitch.Regions.Count - 1;
                    Player.getNavMeshAgent.destination = refPitch.Regions[maxCount - Player.attackPosition_idx].position;
                }
            }
            else if(Player.Team.state == ETeamState.Defending)
            {
                if (Player.Team.Color == TeamColor.Blue)
                {
                    Player.getNavMeshAgent.destination = refPitch.Regions[Player.defendPosition_idx].position;
                }
                else
                {
                    int maxCount = refPitch.Regions.Count - 1;
                    Player.getNavMeshAgent.destination = refPitch.Regions[maxCount - Player.defendPosition_idx].position;
                }
            }
        }

        public override void Execute()
        {
            var refPlayerTeam = Player.Team;
            var refSoccerBall = SoccerBall.s_Instance;

            // 키퍼가 공을 가지고 있을 때
            if (refSoccerBall.Owner)
            {
                if (refSoccerBall.Owner.Role == PlayerBase.Player_Role.Goal_Keeper)
                {
                    CheckAndChangeWaitState();
                    Debug.Log("키퍼가 갖음");
                    return;
                }
            }
            
            // 팀의 상태가 공격이면서
            if (refPlayerTeam.state == ETeamState.Attacking)
                {
                    // 조종선수가 공격수일 때
                    if (refPlayerTeam.ControllingPlayer.Role == PlayerBase.Player_Role.Attakcer)
                    {
                        // Team의 지원선수가 없고 플레이어의 역할이 공격수일 때, SupportAttacker로 전환한다.
                        if (refPlayerTeam.SupportingPlayer == null &&
                            Player.Role == PlayerBase.Player_Role.Attakcer)
                        {
                            Player.stateMachine.ChangeState(aiState.supportAttacker_idx);
                        }
                    }
                    // 조종선수가 수비수일 때
                    else if (refPlayerTeam.ControllingPlayer.Role == PlayerBase.Player_Role.Defender)
                    {
                        if (refPlayerTeam.SupportingPlayer == null)
                        {
                            if (refPlayerTeam.Members[0] == Player)
                            {
                                Player.stateMachine.ChangeState(aiState.supportAttacker_idx);
                            }
                        }
                    }
                }
            // 팀의 상태가 수비이면서
            else if (refPlayerTeam.state == ETeamState.Defending)
                {
                    if (Player.IsClosetTeamMemberToBall)
                    {
                        Player.stateMachine.ChangeState(aiState.chaseBall_idx);
                    }
                }

            CheckAndChangeWaitState();
        }

        public override void Exit() { }

        private void Awake()
        {
            aiState = GetComponent<RootAiState>();
            Player = GetComponent<FieldPlayer>();
        }

        // 조건이 맞으면 Wait상태로 전환해준다.
        private void CheckAndChangeWaitState()
        {
            var refPlayerNavMeshAget = Player.getNavMeshAgent;
            if (refPlayerNavMeshAget.remainingDistance < refPlayerNavMeshAget.stoppingDistance)
            {
                Player.stateMachine.ChangeState(aiState.wait_idx);
            }
        }
    }
}