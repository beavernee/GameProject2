﻿using UnityEngine;
using Utilities.FSM;
using UnityEditor;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(ControlState))]
    public class ControlEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}
