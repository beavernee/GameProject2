﻿using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    public abstract class FieldPlayerState : State
    {
        // 추상 프로퍼티
        public abstract FieldPlayer Player { get; set; }
    }
}