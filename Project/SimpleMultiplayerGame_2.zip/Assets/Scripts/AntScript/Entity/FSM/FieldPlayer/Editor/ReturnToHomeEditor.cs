﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [CustomEditor(typeof(ReturnToHomeState))]
    public class ReturnToHomeEditor : StateEditor
    {
        protected override void OnEnable()
        {
            base.OnEnable();
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}