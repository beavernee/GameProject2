﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/GlobalState")]
    [DisallowMultipleComponent]
    public class GlobalState : FieldPlayerState
    {
        int control_idx;
        public FieldPlayerState controlState = null;

        public override FieldPlayer Player { get; set; }

        public override void Enter() { }

        public override void Execute()
        {
            if (Player.state != EFieldPlayerState.Control)
            {
                if(Player.Team.ControllingPlayer == this.Player)
                {
                    Player.stateMachine.ChangeState(control_idx);
                }
            }
        }

        public override void Exit() { }


        private void Awake()
        {
            Player = GetComponent<FieldPlayer>();

            if (controlState == null)
                controlState = GetComponent<ControlState>();

            control_idx = stateMachine.stateList.FindIndex(g => g.Equals(controlState));

            if(control_idx == -1)
                MyDebug.LogError("ControlState 컴포넌트를 확인해주세요");
        }
    }
}