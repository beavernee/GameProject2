﻿using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/ControlState")]
    [DisallowMultipleComponent]
    public class ControlState : FieldPlayerState
    {
        public override FieldPlayer Player { get; set; }

        public override void Enter()
        {
            Player.state = EFieldPlayerState.Control;

            Player.getNavMeshAgent.isStopped = true;
            Player.Movement.enabled = true;
        }

        public override void Execute()
        {
            if (Player.Team.ControllingPlayer != this.Player)
            {
                Player.stateMachine.ChangeState(0);
            }
            
        }

        public override void Exit()
        {
            Player.getNavMeshAgent.isStopped = false;

            Player.Movement.SetDesiredMovementDirection(Vector3.zero);
            Player.Movement.enabled = false;
        }

        private void Awake()
        {
            Player = GetComponent<FieldPlayer>();
        }
    }
}