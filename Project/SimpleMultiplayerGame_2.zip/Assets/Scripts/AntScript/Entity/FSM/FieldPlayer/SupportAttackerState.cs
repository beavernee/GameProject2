﻿using UnityEngine;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/SupportAttackerState")]
    [DisallowMultipleComponent]
    public class SupportAttackerState : FieldPlayerState
    {
        public override FieldPlayer Player { get; set; }

        public override void Enter()
        {
            Player.state = EFieldPlayerState.SupportAttacker;

            Player.Team.SupportingPlayer = Player;

            Player.getNavMeshAgent.destination = Player.Team.GetSupportSpot;
        }

        public override void Execute()
        {
            // 팀의 현재 상태가 수비상태로 된다면 상태를 변경해준다.
            if(Player.Team.state == ETeamState.Defending)
            {
                Player.stateMachine.ChangeState(0);
                return;
            }

            // 지원위치와 현재 선수가 향하는 위치랑 다를 경우에 갱신해준다.
            if(Player.Team.GetSupportSpot != Player.getNavMeshAgent.destination)
            {
                Player.getNavMeshAgent.SetDestination(Player.Team.GetSupportSpot);
            }

            if (Player.getNavMeshAgent.remainingDistance < Player.getNavMeshAgent.stoppingDistance)
            {
                //Player.transform.LookAt(SoccerBall.s_Instance.transform.position);
            }

            Player.transform.LookAt(SoccerBall.s_Instance.transform.position);
        }

        public override void Exit()
        {
            Player.Team.SupportingPlayer = null;
        }

        private void Awake()
        {
            Player = GetComponent<FieldPlayer>();


        }
    }
}
