﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Manager.GameManager;

namespace AntGame.Entity.FIeldPlayer.FSM
{
    [AddComponentMenu("AntGame/FieldPlayer/FSM/WaitState")]
    [DisallowMultipleComponent]
    public class WaitState : FieldPlayerState
    {
        RootAiState aiState;

        public override FieldPlayer Player { get; set; }

        public override void Enter()
        {
            Player.state = EFieldPlayerState.Wait;

            Player.getNavMeshAgent.SetDestination(Player.transform.position);
            Player.getNavMeshAgent.isStopped = true;
        }

        public override void Execute()
        {
            if(GameManager.s_Instance.IsStarted)
            {
                if (Player.Team.state == ETeamState.Defending)
                {
                    // 공에 근접플레이어는 공을 쫓는다.
                    if (Player.IsClosetTeamMemberToBall)
                    {
                        // 공의 추격상태로 변경해준다.
                        Player.stateMachine.ChangeState(aiState.chaseBall_idx);
                    }
                }

                Player.transform.LookAt(SoccerBall.s_Instance.transform);

                Player.stateMachine.ChangeState(0);
            }
        }

        public override void Exit()
        {
            Player.getNavMeshAgent.isStopped = false;
        }

        private void Awake()
        {
            aiState = GetComponent<RootAiState>();
            Player = GetComponent<FieldPlayer>();   
        }
    }
}