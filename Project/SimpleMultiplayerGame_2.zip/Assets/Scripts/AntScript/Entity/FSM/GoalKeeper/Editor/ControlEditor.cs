﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    [CustomEditor(typeof(ControlState))]
    public class ControlEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}