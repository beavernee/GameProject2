﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    [CustomEditor(typeof(TendGoalState))]
    public class TendGoalEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}