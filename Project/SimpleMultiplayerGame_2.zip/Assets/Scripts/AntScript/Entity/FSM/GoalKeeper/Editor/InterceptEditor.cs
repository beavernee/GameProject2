﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    [CustomEditor(typeof(InterceptState))]
    public class InterceptEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}