﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Manager.GameManager;

namespace AntGame.Entity.Keeper.FSM
{
    [AddComponentMenu("AntGame/GoalKeeper/FSM/TendGoalState")]
    [DisallowMultipleComponent]
    public class TendGoalState : GoalKeeperState
    {
        RootAiState rootState;

        public override void Enter()
        {
            Keeper.state = EKeeperState.TendGoal;

            Keeper.getNavMeshAgent.isStopped = true;
        }

        public override void Execute()
        {
            if (GameManager.s_Instance.IsStarted)
            {
                if (Keeper.Team.state == ETeamState.Defending)
                {
                    // 팀의 상태가 수비이면서 공과 키퍼의 거리가 범위안에 들어오면 공을 가로채기 위한 상태로 전환
                    if (CheckKeeperAndBallDistance())
                    {
                        Keeper.stateMachine.ChangeState(rootState.intercept_idx);
                    }
                }

                transform.LookAt(SoccerBall.s_Instance.transform);

                Keeper.stateMachine.ChangeState(0);
            }
        }

        public override void Exit()
        {
            Keeper.getNavMeshAgent.isStopped = false;
        }

        protected override void Awake()
        {
            base.Awake();

            rootState = GetComponent<RootAiState>();
        }
    }
}