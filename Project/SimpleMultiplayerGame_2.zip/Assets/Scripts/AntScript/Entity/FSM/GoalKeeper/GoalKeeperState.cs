﻿using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    public abstract class GoalKeeperState : State
    {
        Vector3 m_prevPosition;

        protected GoalKeeper Keeper {
            get;
            private set;
        }
        
        /// <summary>
        /// 키퍼의 영역을 벗어나면 수치를 고정시켜주는 함수
        /// </summary>
        protected bool CheckAreaOutOfRange()
        {
            Vector3 pointingToKeeper = this.Keeper.transform.position - Keeper.Team.HomeGoal.transform.position;

            m_prevPosition = Keeper.transform.position;

            // 빼고싶은데
            if(Mathf.Abs(pointingToKeeper.z) > 1.75f)
            {
                if (pointingToKeeper.z > 0)
                    m_prevPosition = new Vector3(m_prevPosition.x, m_prevPosition.y, 1.6f);
                else
                    m_prevPosition = new Vector3(m_prevPosition.x, m_prevPosition.y, -1.6f);
            }

            if (Mathf.Abs(pointingToKeeper.x) > 2.8f)
            {
                if(Keeper.Team.Color == TeamColor.Red)
                    m_prevPosition = new Vector3(-9.1f, m_prevPosition.y, m_prevPosition.z);
                else
                    m_prevPosition = new Vector3(9.2f, m_prevPosition.y, m_prevPosition.z);
            }

            return true;
        }

        /// <summary>
        /// 매프레임 위치를 검사하고 범위를 벗어나지 못하게 해주는 역할을 한다.
        /// </summary>
        public void UpdateCheckArea()
        {
            if (CheckAreaOutOfRange())
            {
                Keeper.transform.position = m_prevPosition;
            }
        }

        /// <summary>
        /// 키퍼와 공의 거리를 체크해주는 함수
        /// 일정 거리는 기본 6.0f로 설정해둔다. (다른 방법을 이용하게 될 경우에 변경이 필요)
        /// </summary>
        /// <returns></returns>
        public bool CheckKeeperAndBallDistance()
        {
            float distance = Vector3.Distance(Keeper.transform.position, 
                                              SoccerBall.s_Instance.transform.position);

            // 키퍼와 공의 거리가 일정범위안에 있으면 True를 반환해준다.
            if (distance < 4.0f)
                return true;

            return false;
        }

        protected virtual void Awake()
        {
            Keeper = GetComponent<GoalKeeper>();
        }
    }
}