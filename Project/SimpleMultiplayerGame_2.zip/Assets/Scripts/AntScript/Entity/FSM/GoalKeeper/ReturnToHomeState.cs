﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    [AddComponentMenu("AntGame/GoalKeeper/FSM/ReturnToHomeState")]
    [DisallowMultipleComponent]
    public class ReturnToHomeState : GoalKeeperState
    {
        RootAiState rootState = null;

        public override void Enter()
        {
            Keeper.state = EKeeperState.ReturnToHome;

            var refPitch = SoccerPitch.s_Instance;

            if(Keeper.Team.Color == TeamColor.Blue)
            {
                Keeper.getNavMeshAgent.destination = refPitch.Regions[Keeper.defendPosition_idx].position;
            }
            else
            {
                int maxCount = refPitch.Regions.Count - 1;
                Keeper.getNavMeshAgent.destination = refPitch.Regions[maxCount - Keeper.defendPosition_idx].position;
            }
        }

        public override void Execute()
        {
            if (Keeper.Team.state == ETeamState.Defending)
            {
                // 팀의 상태가 수비이면서 공과 키퍼의 거리가 범위안에 들어오면 공을 가로채기 위한 상태로 전환
                if (CheckKeeperAndBallDistance())
                {
                    Keeper.stateMachine.ChangeState(rootState.intercept_idx);
                }
            }

            CheckAndChangeWaitState();
        }

        public override void Exit() { }

        // 조건이 맞으면 골대지키는 상태로 전환해준다.
        private void CheckAndChangeWaitState()
        {
            var refKeeperNavMeshAget = Keeper.getNavMeshAgent;
            if (refKeeperNavMeshAget.remainingDistance < refKeeperNavMeshAget.stoppingDistance)
            {
                Keeper.stateMachine.ChangeState(rootState.tendGoal_idx);
            }
        }

        protected override void Awake()
        {
            base.Awake();

            rootState = GetComponent<RootAiState>();
        }
    }
}
