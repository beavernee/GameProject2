﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    [AddComponentMenu("AntGame/GoalKeeper/FSM/RootAiState")]
    [DisallowMultipleComponent]
    public class RootAiState : GoalKeeperState
    {
        ReturnToHomeState returnToHomeState = null;
        TendGoalState tendGoalState = null;
        InterceptState interceptState = null;

        public int returnToHome_idx { get; private set; }
        public int tendGoal_idx { get; private set; }
        public int intercept_idx { get; private set; }

        public override void Enter() {
            Keeper.state = EKeeperState.None;

            Keeper.getNavMeshAgent.isStopped = false;
        }

        public override void Execute()
        {
            if (Keeper.Team.state == ETeamState.KickOff)
                Keeper.stateMachine.ChangeState(tendGoal_idx);
            else
                Keeper.stateMachine.ChangeState(returnToHome_idx);
        }

        public override void Exit() { }

        protected override void Awake()
        {
            base.Awake();

            if (returnToHomeState == null) returnToHomeState = GetComponent<ReturnToHomeState>();
            if (tendGoalState == null) tendGoalState = GetComponent<TendGoalState>();
            if (interceptState == null) interceptState = GetComponent<InterceptState>();

            returnToHome_idx = stateMachine.stateList.FindIndex(g => g.Equals(returnToHomeState));
            tendGoal_idx = stateMachine.stateList.FindIndex(g => g.Equals(tendGoalState));
            intercept_idx = stateMachine.stateList.FindIndex(g => g.Equals(interceptState));
        }
    }
}
