﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    [AddComponentMenu("AntGame/GoalKeeper/FSM/GlobalState")]
    [DisallowMultipleComponent]
    public class GlobalState : GoalKeeperState
    {
        int control_idx;
        public ControlState controlState = null;

        public override void Enter() { }

        public override void Execute()
        {
            if(Keeper.state != EKeeperState.Control)
            {
                if(Keeper.Team.ControllingPlayer == this.Keeper)
                {
                    Keeper.stateMachine.ChangeState(control_idx);
                }
            }
        }

        public override void Exit() { }

        protected override void Awake()
        {
            base.Awake();

            if (controlState == null)
                controlState = GetComponent<ControlState>();

            control_idx = stateMachine.stateList.FindIndex(g => g.Equals(controlState));
        }
    }
}
