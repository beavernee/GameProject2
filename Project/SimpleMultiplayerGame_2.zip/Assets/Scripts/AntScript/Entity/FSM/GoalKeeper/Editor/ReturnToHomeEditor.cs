﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    [CustomEditor(typeof(ReturnToHomeState))]
    public class ReturnToHomeEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}