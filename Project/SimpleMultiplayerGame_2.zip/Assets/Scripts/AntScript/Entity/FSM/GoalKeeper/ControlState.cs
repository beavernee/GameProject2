﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    /// <summary>
    /// 키퍼를 제어하고 있을 때
    /// </summary>
    [AddComponentMenu("AntGame/GoalKeeper/FSM/ControlState")]
    [DisallowMultipleComponent]
    public class ControlState : GoalKeeperState
    {
        int putBall_idx;
        public PutBallBackState putBallState = null;
        
        public override void Enter()
        {
            Keeper.state = EKeeperState.Control;

            Keeper.getNavMeshAgent.isStopped = true;
            Keeper.Movement.enabled = true;
        }

        public override void Execute()
        {
            UpdateCheckArea();

            // 공의 소유자가 키퍼가 될 경우에 PutBallBackState로 전환해준다.
            if (SoccerBall.s_Instance.Owner == this.Keeper)
            {
                Keeper.stateMachine.ChangeState(putBall_idx);
            }

            Keeper.transform.LookAt(SoccerBall.s_Instance.transform);
        }

        public override void Exit()
        {
            Keeper.getNavMeshAgent.isStopped = false;

            Keeper.Movement.SetDesiredMovementDirection(Vector3.zero);
            Keeper.Movement.enabled = false;
        }

        protected override void Awake()
        {
            base.Awake();

            if (putBallState == null) putBallState = GetComponent<PutBallBackState>();

            putBall_idx = stateMachine.stateList.FindIndex(g => g.Equals(putBallState));
        }
    }
}
