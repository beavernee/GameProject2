﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    /// <summary>
    /// 키퍼가 공을 제어하고 있는 상태
    /// </summary>
    [AddComponentMenu("AntGame/GoalKeeper/FSM/PutBallBackState")]
    public class PutBallBackState : GoalKeeperState
    {
        bool m_bTimeOut;
        Coroutine runningCoroutine = null;

        public override void Enter()
        {
            // Control, PutBallBack 같은 로직을 단순 반복이 된다 (성능에 큰영향X)
            Keeper.getNavMeshAgent.isStopped = true;
            Keeper.Movement.enabled = true;

            // + 적군의 Controlling을 잠깐 Null상태로 만들어주고
            Keeper.Team.Oppenent.ControllingPlayer = null;

            // 모든 선수들을 홈으로 보낸다.
            Keeper.Team.ReturnAllFieldPlayersToHome();
            Keeper.Team.Oppenent.ReturnAllFieldPlayersToHome();

            runningCoroutine = StartCoroutine(TimeCalcCoroutine());
        }

        public override void Execute()
        {
            UpdateCheckArea();

            // 일정시간 지나면 강제로 패스하게 만든다.
            if (m_bTimeOut)
            {
                // 공과 인접한 플레이어에게 패스
                Keeper.Kick(Keeper.Team.PlayerClosestToBall.gameObject, false);
                Keeper.Team.ControllingPlayer = Keeper.Team.PlayerClosestToBall;
            }

            // 팀의 조작플레이어가 키퍼가 아니게 되면 상태를 변환해준다.
            if (Keeper.Team.ControllingPlayer != this.Keeper)
            {
                Keeper.stateMachine.ChangeState(0);
            }
        }

        public override void Exit()
        {
            Keeper.getNavMeshAgent.isStopped = false;

            Keeper.Movement.SetDesiredMovementDirection(Vector3.zero);
            Keeper.Movement.enabled = false;

            // 적군의 컨트롤 샛팅
            Keeper.Team.Oppenent.ControllingPlayer = Keeper.Team.Oppenent.Members[0];

            StopCoroutine(runningCoroutine);
        }

        /// <summary>
        /// 시간을 계산해주는 코루틴
        /// </summary>
        private IEnumerator TimeCalcCoroutine()
        {
            float _time = 0.0f;
            float _maxTime = 3.0f;

            if (m_bTimeOut)
                m_bTimeOut = false;

            while(_time < _maxTime)
            {
                _time += Time.deltaTime;
                Debug.Log("코루틴돈다");
                yield return null;
            }

            m_bTimeOut = true;
        }
    }
}