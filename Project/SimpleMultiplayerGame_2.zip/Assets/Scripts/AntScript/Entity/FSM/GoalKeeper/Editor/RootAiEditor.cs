﻿using UnityEditor;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Entity.Keeper.FSM
{
    [CustomEditor(typeof(RootAiState))]
    public class RootAiEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawButton()
        {
            RootAiState _Target = (RootAiState)target;

            int idx = _Target.stateMachine.stateList.FindIndex(g => g.Equals(_Target));

            if (idx == -1)
            {
                if (GUILayout.Button("Add to FSM List"))
                {
                    _Target.AddToFSMList(true);
                }
            }
            else
            {
                if (GUILayout.Button("Remove to FSM List"))
                {
                    _Target.RemoveToFSMList();
                }
            }
        }
    }
}
