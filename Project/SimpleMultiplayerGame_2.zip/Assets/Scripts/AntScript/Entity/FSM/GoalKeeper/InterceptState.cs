﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Entity.Keeper.FSM
{
    /// <summary>
    /// FieldPlayer의 ChaseBall이랑 굉장히 흡사하다.
    /// 상태들을 재사용할 수 있게 변경할 수 있어보이는데... 일단 구현
    /// </summary>
    [AddComponentMenu("AntGame/GoalKeeper/FSM/InterceptState")]
    [DisallowMultipleComponent]
    public class InterceptState : GoalKeeperState
    {
        float m_fPrevStoppingDistance;

        public override void Enter()
        {
            Keeper.state = EKeeperState.Intercept;

            m_fPrevStoppingDistance = Keeper.getNavMeshAgent.stoppingDistance;
            Keeper.getNavMeshAgent.stoppingDistance = 0;
        }

        public override void Execute()
        {
            if(Keeper.Team.state == ETeamState.Attacking)
            {
                Keeper.stateMachine.ChangeState(0);
            }

            UpdateCheckArea();

            Keeper.getNavMeshAgent.SetDestination(SoccerBall.s_Instance.transform.position);
        }

        public override void Exit()
        {
            Keeper.getNavMeshAgent.stoppingDistance = m_fPrevStoppingDistance;
        }
    }
}