﻿using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Team.FSM
{
    [AddComponentMenu("AntGame/Team/FSM/Attacking")]
    public class Attacking : TeamState
    {
        int defending_idx = -1;
        public TeamState defending = null;

        public override SoccerTeam Team
        {
            get; set;
        }

        private void Awake()
        {
            Team = GetComponent<SoccerTeam>();
            defending_idx = stateMachine.stateList.FindIndex(g => g.GetType().Equals(defending.GetType()));
        }

        #region Functions
        public override void Enter()
        {
            Team.state = ETeamState.Attacking;
        }

        public override void Execute()
        {
            //  SoccerBall.s_Instance.Owner.Role == Entity.PlayerBase.Player_Role.Goal_Keeper
            if (SoccerBall.s_Instance.Owner == null )
                return;

            if (SoccerBall.s_Instance.Owner.Team != this.Team)
                Team.stateMachine.ChangeState(defending_idx);

            if (Team.ControllingPlayer)
            {
                // 최적의 경로는 공격상태 일 때, 최적의 서포팅 위치를 검사한다.
                Team.SupportSpotCalc.DetermineBestSupportingPosition();
            }
        }

        public override void Exit()
        {
            for (int i = 0; i < Team.Members.Count; i++)
            {
                Team.Members[i].SetAIState();
            }
        }
        #endregion
    }
}