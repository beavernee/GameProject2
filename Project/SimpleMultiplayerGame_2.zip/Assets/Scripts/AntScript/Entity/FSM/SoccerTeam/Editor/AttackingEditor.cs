﻿using UnityEngine;
using Utilities.FSM;
using UnityEditor;

namespace AntGame.Team.FSM
{
    [CustomEditor(typeof(Attacking))]
    public class AttackingEditor : StateEditor
    {
        SerializedProperty defendingProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            defendingProperty = serializedObject.FindProperty("defending");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(defendingProperty);
            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }
    }
}
