﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Team.FSM
{
    [CustomEditor(typeof(GlobalState))]
    public class GlobalStateEditor : StateEditor
    {
        SerializedProperty kickOffProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            kickOffProperty = serializedObject.FindProperty("kickOff");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(kickOffProperty);
            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }
    }
}