﻿using System.Collections.Generic;
using UnityEngine;
using AntGame.Manager.GameManager;

namespace AntGame.Team.FSM
{
    [AddComponentMenu("AntGame/Team/FSM/PrepareForKickOff")]
    public class PrepareForKickOff : TeamState
    {
        int attacking_idx = -1;
        int defending_idx = -1;

        public TeamState attacking = null;
        public TeamState defending = null;

        private void Awake()
        {
            Team = GetComponent<SoccerTeam>();
            attacking_idx = stateMachine.stateList.FindIndex(g => g.GetType().Equals(attacking.GetType()));
            defending_idx = stateMachine.stateList.FindIndex(g => g.GetType().Equals(defending.GetType()));
        }

        public override SoccerTeam Team
        {
            get; set;
        }

        public override void Enter()
        {
            Team.PlayerClosestToBall = null;
            Team.SupportingPlayer = null;

            Team.ControllingPlayer.Movement.SetDesiredMovementDirection(Vector3.zero);

            Team.state = ETeamState.KickOff;
        }

        public override void Execute()
        {
            if(GameManager.s_Instance.IsStarted)
            {
                if (Team.IsKickOffbyTeam)
                    Team.stateMachine.ChangeState(attacking_idx);
                else
                    Team.stateMachine.ChangeState(defending_idx);
            }
        }

        public override void Exit()
        {
            //if (!GameManager.s_Instance.IsStarted)
            //    StartCoroutine(GameManager.s_Instance.GameStartCoroutine());

            GameManager.s_Instance.PlayStart();

            // Team.Members.Count
            for (int i = 0; i < 3; i++)
            {
                Team.Members[i].SetAIState();
            }
        }
    }
}