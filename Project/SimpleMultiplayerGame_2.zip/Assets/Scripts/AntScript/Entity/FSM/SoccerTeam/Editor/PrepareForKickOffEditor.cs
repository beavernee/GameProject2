﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;


namespace AntGame.Team.FSM
{
    [CustomEditor(typeof(PrepareForKickOff))]
    public class PrepareForKickOffEditor : StateEditor
    {
        SerializedProperty attackProperty;
        SerializedProperty defendingProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            attackProperty = serializedObject.FindProperty("attacking");
            defendingProperty = serializedObject.FindProperty("defending");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(attackProperty);
            EditorGUILayout.PropertyField(defendingProperty);
            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }
    }
}
