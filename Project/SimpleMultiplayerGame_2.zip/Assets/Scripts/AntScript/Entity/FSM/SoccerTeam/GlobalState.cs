﻿using System.Collections.Generic;
using UnityEngine;
using AntGame.Manager.GameManager;

// GlobalState vs GameManager 둘 중 어디서 관리하게 할 지 생각해봤는데
// GlobalState가 더 알맞는 것으로 판단.

namespace AntGame.Team.FSM
{
    [AddComponentMenu("AntGame/Team/FSM/GlobalState")]
    public class GlobalState : TeamState
    {
        int kickOff_idx = -1;
        public TeamState kickOff = null;

        public override SoccerTeam Team
        {
            get; set;
        }

        public override void Enter() { }

        public override void Execute()
        {
            if (GameManager.s_Instance.state == EGameState.Playing) {
                if (Team.HomeGoal.IsScored)
                {
                    Team.stateMachine.ChangeState(kickOff_idx);
                    Team.IsKickOffbyTeam = true;

                    return;
                }

                if (Team.OppenentGoal.IsScored)
                {
                    Team.stateMachine.ChangeState(kickOff_idx);
                    Team.IsKickOffbyTeam = false;

                    return;
                }
            }
        }

        public override void Exit() { }

        private void Awake()
        {
            Team = GetComponent<SoccerTeam>();

            kickOff_idx = stateMachine.stateList.FindIndex(g => g.GetType().Equals(kickOff.GetType()));
        }
    }
}