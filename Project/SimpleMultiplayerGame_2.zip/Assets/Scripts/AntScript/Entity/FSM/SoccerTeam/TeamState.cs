﻿using UnityEngine;
using Utilities.FSM;

namespace AntGame.Team.FSM
{
    public abstract class TeamState : State
    {
        // 추상 프로퍼티
        public abstract SoccerTeam Team { get; set; }
    }
}