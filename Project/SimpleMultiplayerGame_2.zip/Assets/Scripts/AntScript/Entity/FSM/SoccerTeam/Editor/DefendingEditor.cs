﻿using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Team.FSM
{
    [CustomEditor(typeof(Defending))]
    public class DefendingEditor : StateEditor
    {
        SerializedProperty attackProperty;

        protected override void OnEnable()
        {
            base.OnEnable();

            attackProperty = serializedObject.FindProperty("attacking");
        }

        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawInspectorGUI()
        {
            EditorGUILayout.PropertyField(attackProperty);
            serializedObject.ApplyModifiedProperties();

            base.DrawInspectorGUI();
        }
    }
}