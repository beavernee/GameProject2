﻿using System.Collections.Generic;
using UnityEngine;

// Note.
// 4.21 SoccerTeam의 상태를 설계
// state를 추상클래스로 설계를 했었다.
// m_Entity는 GameObject로 설정을 했음
// C#에서는 다운캐스팅이 활성화되지않음
// 각 상태에 SoccerTeam을 캐싱해두고 사용해야한다.
//
namespace AntGame.Team.FSM
{
    [AddComponentMenu("AntGame/Team/FSM/Defending")]
    public class Defending : TeamState
    {        
        int attacking_idx = -1;

        public TeamState attacking = null;

        // 각 상태에 SoccerTeam을 캐싱해두고 사용해야한다.
        public override SoccerTeam Team
        {
            get; set;
        }

        private void Awake()
        {
            Team = GetComponent<SoccerTeam>();
            attacking_idx = stateMachine.stateList.FindIndex(g => g.GetType().Equals(attacking.GetType()));
        }

        #region Functions
        public override void Enter()
        {
            Team.state = ETeamState.Defending;
        }

        public override void Execute()
        {
            if (SoccerBall.s_Instance.Owner == null)
                return;

            if (SoccerBall.s_Instance.Owner.Team == this.Team)
                Team.stateMachine.ChangeState(attacking_idx);
        }

        public override void Exit()
        {
            for(int i = 0; i < Team.Members.Count; i++)
            {
                Team.Members[i].SetAIState();
            }
        }

        #endregion
    }
}
