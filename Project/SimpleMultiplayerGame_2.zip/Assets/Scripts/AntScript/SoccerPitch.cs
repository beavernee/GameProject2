﻿using System.Collections.Generic;
using UnityEngine;
using Utilities;

namespace AntGame
{
    /// <summary>
    /// 경기장
    /// </summary>
    public class SoccerPitch : MonoBehaviour {

        public static SoccerPitch s_Instance;

        // Region을 일단 MonoBehaviour로 설정한다.
        [SerializeField] List<Region> m_Regions = new List<Region>();

        public List<Region> Regions { get { return m_Regions; } }

        private void Awake()
        {
            if (s_Instance == null)
                s_Instance = this;
            else
                Destroy(gameObject);
        }

        private void OnDrawGizmosSelected()
        {
            for(int i = 0; i < Regions.Count; i++)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawWireSphere(Regions[i].position, 0.2f);
            }
        }
    }

    /// <summary>
    /// 경기장의 지역 및 지원지점에 사용된다.
    /// </summary>
    [System.Serializable]
    public class Region
    {
        public bool toggle;
        
        public Vector3 position;

        public float score;
    }

}
