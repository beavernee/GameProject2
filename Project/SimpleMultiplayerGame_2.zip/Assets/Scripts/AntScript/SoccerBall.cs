﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities;
using AntGame.Entity;

namespace AntGame
{
    //추가리스트
    //Note.뺏긴놈은 아주잠깐동안 SoccerBall를 가질수없는 로직을 만들어준다. --> 5/9 완료(코루틴활용)
 
    /// <summary>
    /// 공의 대한 클래스
    /// OnCollisionEnter를 이용해 소유권을 변경시켜준다.
    /// </summary>
    //[RequireComponent(typeof(SphereCollider))]
    public class SoccerBall : Singleton<SoccerBall>
    {
        // 공을 가지고 있는 선수를 가리키기 위함

        // 확인용
        [SerializeField] PlayerBase m_Owner = null;

        [SerializeField] PlayerBase m_preOwner = null;
        [SerializeField] SoccerTeam m_curTeam = null;

        [SerializeField] Rigidbody rb;

        #region Properties

        public PlayerBase Owner
        {
            get { return m_Owner; }
            private set { m_Owner = value; }
        }

        // 이전주인을 어떻게 참조하고 있을지 생각해본다.
        public PlayerBase PreOwner
        {
            get { return m_preOwner; }
            set { m_preOwner = value; }
        }

        public SoccerTeam CurTeam
        {
            get { return m_curTeam; }
            set { m_curTeam = value; }
        }

        #endregion


        #region Functions

        /// <summary>
        /// 플레이어가 슛팅했을 때 호출되는 함수
        /// </summary>
        /// <param name="dir">날라갈 방향</param>
        /// <param name="force">Rigidbody에 가할 힘</param>
        public void Kicked(Vector3 _dir, float _force)
        {
            // 귀속을 풀고
            transform.SetParent(null);

            // 방향으로 force만큼 힘을 가한다.
            rb.AddForce(_dir * _force);

            BelongToPlayer();

            // 킥을 찰 때는 FreezePositonX , Z를 false로 변경해준다.
            SetRigidbody(RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionY);
        }


        /// <summary>
        /// 귀속 설정 및 볼의 위치를 변경시켜주는 기능
        /// </summary>
        /// <param name="_target">선수</param>
        public void SetEscheat(PlayerBase _target)
        {
            if(_target.Role != PlayerBase.Player_Role.Goal_Keeper)
                PreOwner = null;

            if (transform.parent != _target.transform)
                transform.SetParent(_target.transform);

            gameObject.transform.localPosition = new Vector3(0, 0, 1);

            //if(_target.Role == PlayerBase.Player_Role.Goal_Keeper)
            //{
            //    var lookTransform = _target.Team.OppenentGoal.transform;
            //    _target.transform.LookAt(lookTransform);
            //}
        }

        private void BelongToPlayer(PlayerBase _player = null)
        {
            if (Owner != null)
                Owner.SetOwnerOfTheBall();

            PreOwner = Owner;

            if (_player != null)
                CurTeam = _player.Team;

            Owner = _player;

            transform.SetParent(null);

            if (Owner)
            {
                Owner.SetOwnerOfTheBall(this);

                if (Owner.Team.ControllingPlayer != _player)
                    Owner.Team.ControllingPlayer = _player;

                transform.SetParent(_player.transform);

                // SetDirection
                transform.forward = _player.transform.forward;
            }

            // Rigidbody 속성변경
            SetRigidbody(RigidbodyConstraints.FreezeAll);
        }

        private void SetRigidbody(RigidbodyConstraints _constraint)
        {   // RigidbodyConstraints.FreezeAll 
            // RigidbodyConstraints.FreezeRotation
            rb.constraints = _constraint;

            transform.position = new Vector3(this.transform.position.x, 0, this.transform.position.z);
        }

        // 뻇을수 있는지 체크
        private bool CheckCanBelongTo(Transform _transform)
        {
            Vector3 convertToLocalPoint = _transform.InverseTransformPoint(transform.position).normalized;

            if (convertToLocalPoint.z > 0)
            {
                Vector3 ToTarget = (transform.position - _transform.position).normalized;

                float dot = Vector3.Dot(ToTarget, _transform.forward);
                
                // PI/5 값보다 클 때 true를 리턴
                if(dot > Mathf.Cos(Mathf.PI * 0.2f))
                {
                    return true;
                }
            }
            return false;
        }

        private IEnumerator PreOwnerCoroutine()
        {
            float waitTime = 0.1f;
            WaitForSeconds waitSeconds = new WaitForSeconds(waitTime);

            float time = 0.0f, maxTime = 1.0f;

            while (true)
            {
                if (PreOwner)
                {
                    time += waitTime;

                    if (time > maxTime)
                    {
                        PreOwner = null;
                        time = 0.0f;
                    }
                }
                else
                {
                    if (time != 0.0f)
                        time = 0.0f;
                }
                yield return waitSeconds;
            }
        }

        #endregion


        #region MonoBehaviour 이벤트함수

        private void Reset()
        {
            rb = GetComponent<Rigidbody>();
            SetRigidbody(RigidbodyConstraints.FreezeAll);

            gameObject.layer = LayerMask.NameToLayer("Ball");
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("Agent"))
            {
                var refPlayerBase = collision.gameObject.GetComponent<PlayerBase>();

                // 선수의 역할이 골키퍼일 경우에 바로 귀속시킨다.
                if(refPlayerBase.Role == PlayerBase.Player_Role.Goal_Keeper)
                {
                    BelongToPlayer(refPlayerBase);

                    SetEscheat(refPlayerBase);
                }
                
                if (!Owner)
                {
                    if (CheckCanBelongTo(collision.transform))
                    {
                        BelongToPlayer(refPlayerBase);
                    }
                }
                else
                {
                    if (Owner.gameObject != collision.gameObject)
                    {
                        if (CheckCanBelongTo(collision.transform))
                        {
                            BelongToPlayer(refPlayerBase);
                        }
                    }
                }
            }
            else if (collision.gameObject.layer == LayerMask.NameToLayer("Wall"))
            {
                if (!Owner)
                {
                    BelongToPlayer();
                }
            }
        }

        // PreOwner 변수를 활용해서 Ball과 충돌이 계속 일어날때, 공의소유관리를 해주기 위함
        private void OnCollisionStay(Collision collision)
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("Agent"))
            {
                if (Owner)
                {
                    if (Owner.gameObject != collision.gameObject)
                    {
                        if (!PreOwner && CheckCanBelongTo(collision.transform))
                        {
                            BelongToPlayer(collision.gameObject.GetComponent<PlayerBase>());
                        }
                    }
                }
                else
                {
                    if (!PreOwner && CheckCanBelongTo(collision.transform))
                    {
                        BelongToPlayer(collision.gameObject.GetComponent<PlayerBase>());
                    }
                }
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.gameObject.layer == LayerMask.NameToLayer("Goal"))
            {
                BelongToPlayer();
            }
        }

        //private void OnTriggerExit(Collider other)
        //{
        //    if(other.gameObject.layer == LayerMask.NameToLayer("Goal"))
        //    {
        //        GetComponentInChildren<SphereCollider>().isTrigger = false;
        //    }
        //}

        protected override void Awake()
        {
            base.Awake();

            if (rb.isKinematic) rb.isKinematic = false;
            SetRigidbody(RigidbodyConstraints.FreezeAll);
        }

        private void Start()
        {
            StartCoroutine(PreOwnerCoroutine());
        }

        private void Update()
        {
            // Owner가 있을 때
            if(Owner)
            {
                // Owner에서 Ball을 가리키는 벡터를 정규화 
                Vector3 OwnerToBall = (this.transform.position - Owner.transform.position).normalized;
                float dot = Vector3.Dot(transform.forward, OwnerToBall);

                // 일정내적값보다 작아지거나, Owner, Ball의 거리가 일정량 멀어지면 귀속을 퓰어준다.
                if(dot < 0.6f 
                    || Vector3.Distance(transform.position, Owner.transform.position) > 1.5f)
                {
                    BelongToPlayer();
                }

            }
        }

        #endregion
    }
}