﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Utilities;

/// <summary>
/// UNET을 이용하게 될 경우 InputModule 수정
/// </summary>
namespace AntGame
{
    /// <summary>
    /// 플레이어 입력관리자
    /// </summary>
    public class InputManager : MonoBehaviour
    {
        public static InputManager s_Instance
        {
            get;
            private set;
        }

        private void Awake()
        {
            s_Instance = this;
        }

    }
}