﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities;

namespace AntGame.Manager.GameManager.UI
{
    public class GameUI : Singleton<GameUI>
    {
        public IEnumerator scoreCoroutine = null;
        public IEnumerator timerCoroutine = null;
        public IEnumerator shootCoroutine = null;

        public ScoreUI scoreUI { get; private set; }
        public ShootGaugeUI shootGaugeUI { get; private set; }
        public TimeUI timeUI { get; private set; }

        protected override void Awake()
        {
            base.Awake();

            scoreUI = GetComponentInChildren<ScoreUI>();
            shootGaugeUI = GetComponentInChildren<ShootGaugeUI>();
            timeUI = GetComponentInChildren<TimeUI>();

            if (timeUI == null || shootGaugeUI == null || scoreUI == null)
                MyDebug.LogError("GameUI를 확인해주세요");
        }
    }
}

