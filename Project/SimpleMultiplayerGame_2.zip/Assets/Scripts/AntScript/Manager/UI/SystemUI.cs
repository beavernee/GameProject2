﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities;

namespace AntGame.Manager.GameManager.UI
{
    public abstract class SystemUI : MonoBehaviour
    {
        protected GameUI m_gameUI;

        protected abstract IEnumerator ActiveCoroutine();

        protected virtual void Awake()
        {
            m_gameUI = GetComponentInParent<GameUI>();

            if (m_gameUI == null)
                MyDebug.LogError("GameUI를 확인해주세요");
        }
    }
}