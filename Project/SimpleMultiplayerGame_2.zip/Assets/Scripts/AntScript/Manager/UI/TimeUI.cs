﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Utilities;

namespace AntGame.Manager.GameManager.UI
{
    [DisallowMultipleComponent]
    public class TimeUI : SystemUI
    {
        public float Timer { get; private set; }

        [SerializeField] Text m_TimerText;

        protected override IEnumerator ActiveCoroutine()
        {
            while (true)
            {
                Timer -= Time.deltaTime;

                if (Timer < 0)
                {
                    GameManager.s_Instance.state = EGameState.EndGame;
                    Timer = 0.0f;
                }

                int minute, seconds;
                ShowTimer(out minute, out seconds);

                yield return null;
            }
        }

        private void ShowTimer(out int _minute, out int _seconds)
        {
            _minute = (int)(Timer / 60);
            _seconds = (int)(Timer - _minute * 60);

            m_TimerText.text = string.Format((_seconds < 10) ? "0{0} : 0{1}" : "0{0} : {1}",
                                            _minute,
                                            _seconds);
        }


        private void Start()
        {
            if (m_TimerText == null)
                MyDebug.LogError("TimeUI Text 할당되어있지 않음");

            // 5분
            Timer = 300.0f;
            int m, s;
            ShowTimer(out m, out s);

            m_gameUI.timerCoroutine = ActiveCoroutine();
        }
    }
}