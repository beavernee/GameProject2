﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Utilities;

namespace AntGame.Manager.GameManager.UI
{
    [DisallowMultipleComponent]
    public class ScoreUI : SystemUI
    {
        [SerializeField] Text m_RedScore;
        [SerializeField] Text m_BlueScore;

        protected override IEnumerator ActiveCoroutine()
        {
            while (true)
            {
                int redScore = GameManager.s_Instance.RedTeam.OppenentGoal.NumGoalsScored;
                int blueScore = GameManager.s_Instance.BlueTeam.OppenentGoal.NumGoalsScored;

                if (int.Parse(m_RedScore.text) != redScore)
                    m_RedScore.text = redScore.ToString();

                if (int.Parse(m_BlueScore.text) != blueScore)
                    m_BlueScore.text = blueScore.ToString();

                yield return null;
            }
        }

        private void Start()
        {
            if (m_RedScore == null || m_BlueScore == null)
                MyDebug.LogError("ScoreUI의 멤버변수가 할당되지 않았습니다.");
            else
            {
                m_RedScore.text = "0";
                m_BlueScore.text = "0";

                m_gameUI.scoreCoroutine = ActiveCoroutine();
            }
        }
    }
}