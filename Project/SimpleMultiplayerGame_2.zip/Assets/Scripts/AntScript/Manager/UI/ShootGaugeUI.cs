﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Utilities;

namespace AntGame.Manager.GameManager.UI
{
    [DisallowMultipleComponent]
    public class ShootGaugeUI : SystemUI
    {
        List<Text> m_gaugeList = new List<Text>();

        WaitForSeconds wait = null;

        float m_waitTime;

        public int currentGauge { get; private set; }

        protected override IEnumerator ActiveCoroutine()
        {
            while (true)
            {
                if (currentGauge > m_gaugeList.Count - 1)
                    currentGauge = 0;

                ChangeGauge(currentGauge++);
                yield return wait;
            }
        }

        /// <summary>
        /// 게이지 변경
        /// </summary>
        private void ChangeGauge(int _idx)
        {
            m_gaugeList[_idx].color = Color.red;

            if (_idx == 0)
                m_gaugeList[m_gaugeList.Count - 1].color = Color.white;
            else
                m_gaugeList[_idx - 1].color = Color.white;
        }

        protected override void Awake()
        {
            base.Awake();

            Text[] gaugeList = GetComponentsInChildren<Text>();
            foreach(var gauge in gaugeList)
            {
                if (gauge.CompareTag("ShootGauge"))
                {
                    m_gaugeList.Add(gauge);
                }
            }

            m_waitTime = 1.0f / m_gaugeList.Count;

            wait = new WaitForSeconds(m_waitTime);
        }

        private void Start()
        {
            m_gameUI.shootCoroutine = ActiveCoroutine();
        }
    }
}