﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities;
using AntGame.Entity;
using Utilities.FSM;

// GameManager에게 어떠한 기능을 부여할지 생각해본다.
// 게임관리자 --> 타이머 및 여러 기능들을 부여하자
namespace AntGame.Manager.GameManager
{
    public enum EGameState
    {
            None
            , StartUp
            , KickOff
            , Playing
            , Goal
            , EndGame
    }

    [RequireComponent(typeof(StateMachine))]
    public class GameManager : MonoBehaviour , IFSM_object
    {
        public EGameState state = EGameState.None;

        public static GameManager s_Instance;

        [SerializeField] SoccerTeam Team_RED;
        [SerializeField] SoccerTeam Team_BLUE;

        public UI.GameUI GameSystemUI { get; set; }

        public SoccerTeam RedTeam { get { return Team_RED; } }
        public SoccerTeam BlueTeam { get { return Team_BLUE; } }

        public bool IsStarted { get; private set; }

        public StateMachine stateMachine { get; set; }

        public TeamColor KickOffStartTeam { get; private set; }

        /// <summary>
        /// PrepareForKickOff에서 호출한다.
        /// </summary>
        public void PlayStart()
        {
            if(!IsStarted)
                IsStarted = true;
        }

        public void PlayStop()
        {
            if (IsStarted)
            {
                IsStarted = false;
            }
        }
        
        // _teamColor가 득점했을 때,
        public void GetScored(TeamColor _team)
        {
            state = EGameState.Goal;

            if(_team == TeamColor.Red)
            {
                Debug.Log("Red Team이 득점했다.");
                KickOffStartTeam = TeamColor.Blue;
            }
            else
            {
                Debug.Log("Blue Team이 득점헀다.");
                KickOffStartTeam = TeamColor.Red;
            }
        }
        
        private void Awake()
        {
            s_Instance = this;

            stateMachine = GetComponent<StateMachine>();

            state = EGameState.StartUp;
        }

        private void Start()
        {
            GameSystemUI = UI.GameUI.s_Instance;

            // 시작
            stateMachine.ChangeState(0);
        }

        private void Update()
        {
            if(stateMachine.stateList.Count > 0)
                stateMachine.EveryFrame();
        }
    }
}