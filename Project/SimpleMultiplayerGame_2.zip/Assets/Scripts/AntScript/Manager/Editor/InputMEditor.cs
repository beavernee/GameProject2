﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace AntGame
{
    //[CustomEditor(typeof(InputManager))]
    public class InputMEditor : Editor
    {

        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}