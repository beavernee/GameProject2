﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace AntGame.Network
{
    public class NetworkManager : UnityEngine.Networking.NetworkManager
    {
        
    }
}