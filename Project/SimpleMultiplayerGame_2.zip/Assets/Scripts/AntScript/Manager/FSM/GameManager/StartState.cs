﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Manager.GameManager.FSM {

    /// <summary>
    /// Start 상태
    /// </summary>
    [AddComponentMenu("AntGame/GameManager/FSM/StartState")]
    [DisallowMultipleComponent]
    public class StartState : GameState
    {
        KickOffState kickOffState = null;

        public int kickOff_idx { get; private set; }

        public override void Enter()
        {
            // Random.Range(0, 2); // 0,1 랜덤
            int num = 0;

            StartReady(num);
        }

        public override void Execute()
        {
            // KickOff 진입을 늦게하려면 다른 방법을 이용한다.
            if(GameManager.s_Instance.state == EGameState.StartUp)
            {
                stateMachine.ChangeState(kickOff_idx);
            }
        }

        public override void Exit()
        { }

        private void StartReady(int num)
        {
            if (num == 0)
                SetKickOff(TeamColor.Red);
            else
                SetKickOff(TeamColor.Blue);

            Game.state = EGameState.StartUp;
        }

        protected override void Awake()
        {
            base.Awake();

            if(kickOffState == null)
                kickOffState = GetComponent<KickOffState>();

            kickOff_idx = stateMachine.stateList.FindIndex(g => g.Equals(kickOffState));
        }
    }
}
