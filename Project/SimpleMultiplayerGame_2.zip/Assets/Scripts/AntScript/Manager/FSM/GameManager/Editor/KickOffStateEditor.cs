﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Manager.GameManager.FSM
{
    [CustomEditor(typeof(KickOffState))]
    public class KickOffStateEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}