﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities.FSM;

namespace AntGame.Manager.GameManager.FSM
{
    public abstract class GameState : State
    {
        protected GameManager Game { get; private set; }

        protected virtual void Awake()
        {
            Game = GetComponent<GameManager>();
        }

        protected void SetKickOff(TeamColor team)
        {
            StartSetting();

            if (team == TeamColor.Red)
            {
                Game.RedTeam.IsKickOffbyTeam = true;
                Game.BlueTeam.IsKickOffbyTeam = false;

                Game.RedTeam.PreemptiveKickOff();
                Game.BlueTeam.NotPreemptiveKickOff();

                SoccerBall.s_Instance.SetEscheat(Game.RedTeam.ControllingPlayer);
            }
            else
            {
                Game.BlueTeam.IsKickOffbyTeam = true;
                Game.RedTeam.IsKickOffbyTeam = false;

                Game.BlueTeam.PreemptiveKickOff();
                Game.RedTeam.NotPreemptiveKickOff();

                SoccerBall.s_Instance.SetEscheat(Game.BlueTeam.ControllingPlayer);
            }
        }

        private void StartSetting()
        {
            Game.RedTeam.ControllingPlayer = Game.RedTeam.Members[0];
            Game.BlueTeam.ControllingPlayer = Game.BlueTeam.Members[0];

            // Team의 상태를 PrepareForKickOff로 변경시켜준다.
            Game.RedTeam.stateMachine.ChangeState(0);
            Game.BlueTeam.stateMachine.ChangeState(0);
        }
    }
}