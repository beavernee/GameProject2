﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Manager.GameManager.FSM
{
    [AddComponentMenu("AntGame/GameManager/FSM/KickOffState")]
    [DisallowMultipleComponent]
    public class KickOffState : GameState
    {
        PlayState playState = null;

        public int playState_idx { get; private set; }

        public override void Enter()
        {
            Game.state = EGameState.KickOff;
        }

        public override void Execute()
        {
            if(Game.IsStarted)
            {
                stateMachine.ChangeState(playState_idx);
            }
        }

        public override void Exit()
        {
        }

        protected override void Awake()
        {
            base.Awake();

            if (playState == null)
                playState = GetComponent<PlayState>();

            playState_idx = stateMachine.stateList.FindIndex(g => g.Equals(playState));
        }
    }
}