﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Manager.GameManager.FSM
{
    [AddComponentMenu("AntGame/GameManager/FSM/PlayState")]
    [DisallowMultipleComponent]
    public class PlayState : GameState
    {
        GoalState goalState = null;
        EndGameState endGameState = null;

        public int goal_idx { get; private set; }
        public int endGame_idx { get; private set; }

        Coroutine timerCoroutine = null;
        Coroutine shootGaugeCoroutine = null;

        public override void Enter()
        {
            Game.state = EGameState.Playing;

            UI.GameUI refGameUI = GameManager.s_Instance.GameSystemUI;

            timerCoroutine = StartCoroutine(refGameUI.timerCoroutine);
            shootGaugeCoroutine = StartCoroutine(refGameUI.shootCoroutine);
        }

        public override void Execute()
        {
            if(Game.state == EGameState.Goal)
            {
                stateMachine.ChangeState(goal_idx);

                return;
            }

            if(Game.state == EGameState.EndGame)
            {
                stateMachine.ChangeState(endGame_idx);

                return;
            }
        }

        public override void Exit()
        {
            StopCoroutine(timerCoroutine);
            StopCoroutine(shootGaugeCoroutine);
        }

        protected override void Awake()
        {
            base.Awake();

            goalState = GetComponent<GoalState>();

            endGameState = GetComponent<EndGameState>();

            goal_idx = stateMachine.stateList.FindIndex(item => item.Equals(goalState));
            endGame_idx = stateMachine.stateList.FindIndex(item => item.Equals(endGameState));

            if (goal_idx == -1 || endGame_idx == -1)
                MyDebug.LogError("GameManager stateMachine stateList를 확인해주세요 (PlayerState Error)");
        }
    }
}
