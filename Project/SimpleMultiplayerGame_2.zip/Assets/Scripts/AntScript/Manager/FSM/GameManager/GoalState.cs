﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Manager.GameManager.FSM
{
    [AddComponentMenu("AntGame/GameManager/FSM/GoalState")]
    [DisallowMultipleComponent]
    public class GoalState : GameState
    {
        KickOffState kickOffState = null;

        public int kickOffState_idx { get; private set; }

        WaitForSeconds wait = new WaitForSeconds(2.0f);

        //Note. 테스트용
        bool goalState = false;

        Coroutine scoreCoroutine = null;

        public override void Enter()
        {
            Game.PlayStop();

            goalState = true;

            scoreCoroutine = StartCoroutine(Game.GameSystemUI.scoreCoroutine);

            StartCoroutine(Test());

        }

        public override void Execute()
        {
            if(!goalState)
                stateMachine.ChangeState(kickOffState_idx);
        }

        public override void Exit()
        {
            // Goal IsScored 프로퍼티 값을 false로 변경해준다.
            if (Game.RedTeam.HomeGoal.IsScored)
                Game.RedTeam.HomeGoal.IsScored = false;

            if (Game.BlueTeam.HomeGoal.IsScored)
                Game.BlueTeam.HomeGoal.IsScored = false;

            // 킥오프 차례인 팀
            if(GameManager.s_Instance.KickOffStartTeam == TeamColor.Red)
                SetKickOff(TeamColor.Red);
            else
                SetKickOff(TeamColor.Blue);

            StopCoroutine(scoreCoroutine);
        }

        private IEnumerator Test()
        {
            Debug.Log("골!!");

            yield return wait;

            goalState = false;
        }

        protected override void Awake()
        {
            base.Awake();

            if (kickOffState == null)
                kickOffState = GetComponent<KickOffState>();

            kickOffState_idx = stateMachine.stateList.FindIndex(g => g.Equals(kickOffState));

            if (kickOffState_idx == -1)
                MyDebug.LogError("GameManager stateMachine stateList를 확인해주세요 (GoalState Error)");
        }
    }
}