﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Manager.GameManager.FSM
{
    [CustomEditor(typeof(EndGameState))]
    public class EndGameStateEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}
