﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Manager.GameManager.FSM
{
    [CustomEditor(typeof(StartState))]
    public class StartStateEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }

        protected override void DrawButton()
        {
            StartState _Target = (StartState)target;

            int idx = _Target.stateMachine.stateList.FindIndex(g => g.Equals(_Target));

            if (idx == -1)
            {
                if (GUILayout.Button("Add to FSM List"))
                {
                    _Target.AddToFSMList(true);
                }
            }
            else
            {
                if (GUILayout.Button("Remove to FSM List"))
                {
                    _Target.RemoveToFSMList();
                }
            }
        }
    }
}