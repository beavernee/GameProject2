﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AntGame.Manager.GameManager.FSM
{
    [AddComponentMenu("AntGame/GameManager/FSM/EndGameState")]
    [DisallowMultipleComponent]
    public class EndGameState : GameState
    {
        public override void Enter()
        {
            // EndUI를 나타나게 한다.
        }

        public override void Execute()
        {
            Debug.Log("게임 끝");
        }

        public override void Exit()
        {
        }
    }
}