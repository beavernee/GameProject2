﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Utilities.FSM;

namespace AntGame.Manager.GameManager.FSM
{
    [CustomEditor(typeof(PlayState))]
    public class PlayStateEditor : StateEditor
    {
        public override void OnInspectorGUI()
        {
            DrawInspectorGUI();
        }
    }
}