﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AntGame.Manager.GameManager;

namespace AntGame
{
    /// <summary>
    /// 골대의 끝을 게임 내내 반복하는 오브젝트를 갖고 있는 
    /// 슛을 날리려는 플레이어의 공이 향하는 곳이다.
    /// </summary>
    [RequireComponent(typeof(BoxCollider))]
    public class Goal : MonoBehaviour
    {
        SoccerTeam m_Team;

        //Note.테스트용
        public GameObject tmpDummy;
        public float tempUpX;
        public float tempDownX;
        public bool isMovingUp;

        //골 먹힌 수
        public int NumGoalsScored { get; private set; }

        public bool IsScored { get; set; }

        private void Reset()
        {
            GetComponent<BoxCollider>().isTrigger = true;
        }

        private void Awake()
        {
            BoxCollider boxCol = GetComponent<BoxCollider>();

            if (!boxCol.isTrigger)
                boxCol.isTrigger = true;

            m_Team = GetComponentInParent<SoccerTeam>();

            //Note.테스트용
            if (m_Team.Color == TeamColor.Red)
            {
                tmpDummy.transform.localPosition = new Vector3(0, 0, -0.15f);
                tempUpX = 1.6f - 0.15f;
                tempDownX = -1.6f - 0.15f;
            }
            else
            {
                tmpDummy.transform.localPosition = new Vector3(0, 0, 0.15f);
                tempUpX = 1.6f + 0.15f;
                tempDownX = -1.6f + 0.15f;
            }

            if (m_Team == null)
                MyDebug.LogError("SoccerTeam이 상위오브젝에 있는지 확인(Goal)");
        }

        private void Update()
        {
            if(GameManager.s_Instance.IsStarted)
            {
                if(isMovingUp)
                {
                    tmpDummy.transform.localPosition = new Vector3(0, 0,
                                                                   tmpDummy.transform.localPosition.z + Time.deltaTime * 2);

                    if(tmpDummy.transform.localPosition.z > tempUpX)
                        isMovingUp = false;
                }
                else
                {
                    tmpDummy.transform.localPosition = new Vector3(0, 0,
                                                                   tmpDummy.transform.localPosition.z - Time.deltaTime * 2);


                    if (tmpDummy.transform.localPosition.z < tempDownX)
                        isMovingUp = true;
                }
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!IsScored)
            {
                if (other.gameObject.layer == LayerMask.NameToLayer("Ball"))
                {
                    IsScored = true;

                    NumGoalsScored++;

                    other.GetComponent<SphereCollider>().isTrigger = true;

                    // 이 골대에 공이 들어왔다는 것은 적군이 득점했다는 것을 의미
                    GameManager.s_Instance.GetScored(m_Team.Oppenent.Color);
                }
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if(other.gameObject.layer == LayerMask.NameToLayer("Ball"))
            {
                other.GetComponent<SphereCollider>().isTrigger = false;
            }
        }
    }
}