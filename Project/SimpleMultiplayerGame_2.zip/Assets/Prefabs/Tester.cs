﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 가비지컬렉터 테스터
public class Tester : MonoBehaviour {

    public List<GameObject> test;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //GetType().ToString();
        //가비지컬렉터에 잡힌다.
        // 참조형식이기 때문
        // 최소한으로 이용할 수 있게 생각해보자
        //int index = test.FindIndex(g => g.GetType().Equals(""));
        //GetType으로 할경우에는 괜찮다??
        Check(1);
    }

    // 상태전환을 하는데 
    private bool Check(short i)
    {
        string index = "Hello";

        if (index != "")
            return true;
        else
            return false;
    }
}
