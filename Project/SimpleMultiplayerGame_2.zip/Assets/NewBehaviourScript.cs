﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class NewBehaviourScript : MonoBehaviour {

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Test();		
	}

    [ContextMenu("Test")]
    private void Test()
    {
    }

}

public class TESTFUNC
{ }
